//: Playground - noun: a place where people can play

import UIKit

/*
 1.类的定义
 2.创建类对应的对象
 3.给类的属性赋值
    1> 直接赋值
    2> 通过KVC赋值
 4.可以重写setValue(value: AnyObject?, forUndefinedKey key:,那么字典中没有的字段可以在类中没有对应的属性
 5.override : 重写, 如果写的某一个方法是对父类的方法进行的重写,那么必须在该方法前加上override
 */


class Person : NSObject {
    var age : Int = 0
    
    // override : 重写, 如果写的某一个方法是对父类的方法进行的重写,那么必须在该方法前加上override
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {}
}


let p = Person()
//p.age = 20

p.setValuesForKeysWithDictionary(["age" : 18, "name" : "why"])
print(p.age)
