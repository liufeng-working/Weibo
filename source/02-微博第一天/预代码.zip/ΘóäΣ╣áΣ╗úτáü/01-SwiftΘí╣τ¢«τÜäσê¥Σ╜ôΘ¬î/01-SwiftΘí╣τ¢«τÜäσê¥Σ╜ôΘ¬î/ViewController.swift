//
//  ViewController.swift
//  01-Swift项目的初体验
//
//  Created by apple on 16/3/9.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

private let CellID = "CellID"

// 在swift中遵守协议 : 父类, 协议
class ViewController: UIViewController {
    // MARK:- 属性
    // MARK: 懒加载属性
    private lazy var tableView : UITableView = UITableView()
    
    // MARK:- 系统回调函数
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 初始化UI
        setupUI()
    }
}


extension ViewController {
    // MARK:- 自定义函数
    private func setupUI() {
        // 1.将子控件添加到控制器的View中
        view.addSubview(tableView)
        
        // 2.设置tableView的位置和尺寸
        tableView.frame = view.bounds
        
        // 3.设置tableView属性
        tableView.dataSource = self
        tableView.delegate = self
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: CellID)
    }
}



extension ViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        // 1.创建cell
        let cell = tableView.dequeueReusableCellWithIdentifier(CellID)!
        
        // 2.给cell设置数据
        cell.textLabel?.text = "测试数据\(indexPath.row)"
        
        // 3.返回cell
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("点击了\(indexPath.row)")
    }
}

