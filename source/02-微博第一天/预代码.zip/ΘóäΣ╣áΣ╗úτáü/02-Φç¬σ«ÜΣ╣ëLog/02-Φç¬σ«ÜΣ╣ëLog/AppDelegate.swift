//
//  AppDelegate.swift
//  02-自定义Log
//
//  Created by apple on 16/3/9.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        XMGLog("123")
        return true
    }
}

func XMGLog<T>(message : T, fileName : String = __FILE__, lineNum : Int = __LINE__) {
    #if DEBUG
    
    // 处理fileName
    let file = (fileName as NSString).lastPathComponent
    print("\(file):[\(lineNum)]")
    
    #endif
}