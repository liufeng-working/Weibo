//
//  ViewController.swift
//  02-自定义Log
//
//  Created by apple on 16/3/9.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1.获取所在的文件
        // let file = __FILE__
        
        // 2.获取所在的函数
        // let function = __FUNCTION__
        
        // 3.获取所在的行号
        // let line = __LINE__
        
        XMGLog("123")
    }
}

