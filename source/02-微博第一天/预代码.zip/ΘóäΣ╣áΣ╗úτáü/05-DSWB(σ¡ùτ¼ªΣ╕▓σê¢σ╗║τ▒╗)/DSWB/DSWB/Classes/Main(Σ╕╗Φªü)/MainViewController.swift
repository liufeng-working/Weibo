//
//  MainViewController.swift
//  DSWB
//
//  Created by apple on 16/3/9.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class MainViewController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1.取出json文件
        let jsonPath = NSBundle.mainBundle().pathForResource("MainVCSettings.json", ofType: nil)!
        
        // 2.读取json数据
        guard let jsonData = NSData(contentsOfFile: jsonPath) else {
            return
        }
        
        // 3.将data转成字典
        guard let dicts = try? NSJSONSerialization.JSONObjectWithData(jsonData, options: .MutableContainers) as! [[String : AnyObject]] else {
            return
        }
        
        // 4.遍历子弟那
        for dict in dicts {
            // 1.取出控制器的名称
            guard let childVcName = dict["vcName"] as? String else {
                continue
            }
            
            // 2.取出标题
            guard let title = dict["title"] as? String else {
                continue
            }
            
            // 3.取出图片名称
            guard let imageName = dict["imageName"] as? String else {
                continue
            }
            
            addChildViewController(childVcName, title: title, imageName: imageName)
        }
    }
    
    // MARK:- 添加子控制器
    private func addChildViewController(childVcName: String, title : String, imageName : String) {
        // 添加子控制器
        // -1.获取命名空间
        guard let nameSpace = NSBundle.mainBundle().infoDictionary!["CFBundleExecutable"] as? String else {
            print("没有获取到命名空间")
            return
        }
        
        // 0.创建子控制器
        guard let anyClass = NSClassFromString(nameSpace + "." + childVcName) else {
            print("没有创建出对应的class")
            return
        }
        
        // 1.通过class创建对象
        guard let ChildVcClass = anyClass as? UIViewController.Type else {
            print("没有转成控制器")
            return
        }
        
        // 2.创建子控制器对象
        let childVc = ChildVcClass.init()
        
        // 3.设置子控件的属性
        childVc.title = title
        childVc.tabBarItem.image = UIImage(named: imageName)
        childVc.tabBarItem.selectedImage = UIImage(named: imageName + "_highlighted")
        
        // 4.包装导航控制器
        let childNav = UINavigationController(rootViewController: childVc)
        
        // 5.添加到自控制器数组中
        addChildViewController(childNav)
    }
}
