//
//  MainViewController.swift
//  DSWB
//
//  Created by apple on 16/3/9.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class MainViewController: UITabBarController {
    // MARK:- 懒加载属性
    private lazy var composeBtn : UIButton = UIButton(imageName: "tabbar_compose_icon_add", bgImageName: "tabbar_compose_button")
    private lazy var titleNames : [String] = ["tabbar_home", "tabbar_message_center", "", "tabbar_discover", "tabbar_profile"]
    
    // MARK:- 系统回调函数
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1.添加发布按钮
        addComposetBtn()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        adjustItems()
    }
}

// MARK:- 子控件调整
extension MainViewController {
    private func addComposetBtn() {
        // 1.将控件添加到Tabbar中
        tabBar.addSubview(composeBtn)
        
        // 2.设置位置
        composeBtn.center = CGPoint(x: tabBar.bounds.width * 0.5, y: tabBar.bounds.height * 0.5)
        
        // 3.监听按钮的点击
        composeBtn.addTarget(self, action: "composeBtnClick", forControlEvents: .TouchUpInside)
    }
    
    private func adjustItems() {
        // 遍历item设置其图片
        for i in 0..<tabBar.items!.count {
            // 1.取出item
            let item = tabBar.items![i]
            
            // 2.如果是第2个,则禁止交互
            if i == 2 {
                item.enabled = false
                continue
            }
            
            // 3.设置图片
            item.selectedImage = UIImage(named: titleNames[i] + "_highlighted")
        }
    }
}


// MARK:- 事件监听
extension MainViewController {
    @objc private func composeBtnClick() {
        print("composeBtnClick")
    }
}
