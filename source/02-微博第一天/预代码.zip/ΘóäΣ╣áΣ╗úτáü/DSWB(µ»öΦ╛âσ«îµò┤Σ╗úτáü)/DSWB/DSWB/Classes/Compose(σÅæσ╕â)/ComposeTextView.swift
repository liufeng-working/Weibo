//
//  ComposeTextView.swift
//  DSWB
//
//  Created by apple on 16/3/16.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit
import SnapKit

class ComposeTextView: UITextView {
    // MARK:- 懒加载属性
    lazy var placeHolderLabel : UILabel = UILabel()
    
    // MARK:- 重写构造函数
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        // 添加展位的Label
        setupPlaceHolder()
    }
}


// MARK:- 设置UI界面内容
extension ComposeTextView {
    /// 添加占位的Label
    private func setupPlaceHolder() {
        // 1.添加添加的Label
        addSubview(placeHolderLabel)
        
        // 2.设置位置和尺寸
        placeHolderLabel.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(8)
            make.leading.equalTo(10)
        }
        
        // 3.设置Label的属性
        placeHolderLabel.text = "分享新鲜事..."
        placeHolderLabel.font = font
        placeHolderLabel.textColor = UIColor.lightGrayColor()
        
        // 4.设置textView的左侧位置
        textContainerInset = UIEdgeInsets(top: 8, left: 7, bottom: 0, right: 10)
    }
}