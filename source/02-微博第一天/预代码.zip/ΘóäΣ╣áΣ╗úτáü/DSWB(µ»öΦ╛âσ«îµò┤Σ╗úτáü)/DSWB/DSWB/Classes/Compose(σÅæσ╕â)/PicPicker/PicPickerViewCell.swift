//
//  PicPickerViewCell.swift
//  DSWB
//
//  Created by apple on 16/3/16.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

@objc
protocol PicPickerViewCellDelegate : NSObjectProtocol {
    optional func picPickerViewCellWithaddPhotoBtnClick(cell : PicPickerViewCell)
    optional func PicPickerViewCellWithRemovePhotBtnClick(cell : PicPickerViewCell)
}

class PicPickerViewCell: UICollectionViewCell {
    // MARK:- 控件属性
    @IBOutlet weak var addPhotoBtn: UIButton!
    @IBOutlet weak var removePhotoBtn: UIButton!
    @IBOutlet weak var picImageView: UIImageView!
    
    // MARK:- 定义属性
    var delegate : PicPickerViewCellDelegate?
    var image : UIImage? {
        didSet {
            picImageView.image = image
            picImageView.hidden = image == nil
            removePhotoBtn.hidden = image == nil
            addPhotoBtn.userInteractionEnabled = image == nil
        }
    }
    
    // MARK:- 事件监听
    @IBAction func addPhotoBtnClick() {
        if delegate?.respondsToSelector("picPickerViewCellWithaddPhotoBtnClick:") != nil {
            delegate?.picPickerViewCellWithaddPhotoBtnClick!(self)
        }
    }
    
    @IBAction func removePhotoBtnClick() {
        if delegate?.respondsToSelector("PicPickerViewCellWithRemovePhotBtnClick:") != nil {
            delegate?.PicPickerViewCellWithRemovePhotBtnClick!(self)
        }
    }
}
