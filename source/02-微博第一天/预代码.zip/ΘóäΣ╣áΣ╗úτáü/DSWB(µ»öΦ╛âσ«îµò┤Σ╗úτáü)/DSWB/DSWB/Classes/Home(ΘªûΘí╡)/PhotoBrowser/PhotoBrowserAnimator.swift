//
//  PhotoBrowserAnimator.swift
//  DSWB
//
//  Created by apple on 16/3/20.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

protocol PhotoBrowserPresentedDelegate : NSObjectProtocol {
    func startRectForIndexPath(indexPath : NSIndexPath) -> CGRect
    func endRectForIndexPath(indexPath : NSIndexPath) -> CGRect
    func imageViewForIndexPath(indexPath : NSIndexPath) -> UIImageView
}

protocol PhotoBrowserDismissDelegate : NSObjectProtocol {
    func imageViewForDismissView() -> UIImageView
    func indexPathForDismissView() -> NSIndexPath
}


class PhotoBrowserAnimator: NSObject {
    
    // MARK:- 定义属性
    var isPresented : Bool = false
    var indexPath : NSIndexPath?
    var presentedDelegate : PhotoBrowserPresentedDelegate?
    var dismissDelegate : PhotoBrowserDismissDelegate?
    
    func setIndexPath(indexPath : NSIndexPath, presentedDelegate : PhotoBrowserPresentedDelegate, dismissDelegate : PhotoBrowserDismissDelegate) {
        self.indexPath = indexPath
        self.presentedDelegate = presentedDelegate
        self.dismissDelegate = dismissDelegate
    }
}


extension PhotoBrowserAnimator : UIViewControllerTransitioningDelegate {
    func animationControllerForDismissedController(dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        isPresented = false
        return self
    }
    
    func animationControllerForPresentedController(presented: UIViewController, presentingController presenting: UIViewController, sourceController source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        isPresented = true
        return self
    }
}


extension PhotoBrowserAnimator : UIViewControllerAnimatedTransitioning {
    func transitionDuration(transitionContext: UIViewControllerContextTransitioning?) -> NSTimeInterval {
        return 0.5
    }
    
    func animateTransition(transitionContext: UIViewControllerContextTransitioning) {
        isPresented ? animationForPresentedView(transitionContext) : animationForDismissView(transitionContext)
    }
}


extension PhotoBrowserAnimator {
    private func animationForPresentedView(transitionContext: UIViewControllerContextTransitioning) {
        guard let presentedDelegate = presentedDelegate, indexPath = indexPath else {
            return
        }
        
        // 1.取出弹出的控制器
        let presentedView = transitionContext.viewForKey(UITransitionContextToViewKey)!
        presentedView.hidden = true
        transitionContext.containerView()?.backgroundColor = UIColor.blackColor()
        transitionContext.containerView()?.addSubview(presentedView)
        
        // 2.执行动画
        // 2.1.取出UImageView对象
        let imageView = presentedDelegate.imageViewForIndexPath(indexPath)
        transitionContext.containerView()?.addSubview(imageView)
        
        // 2.2.取出其实位置
        imageView.frame = presentedDelegate.startRectForIndexPath(indexPath)
        
        // 2.3.执行动画,并且设置frame
        UIView.animateWithDuration(transitionDuration(transitionContext), animations: { () -> Void in
            imageView.frame = presentedDelegate.endRectForIndexPath(indexPath)
            }) { (_) -> Void in
                transitionContext.containerView()?.backgroundColor = UIColor.clearColor()
                transitionContext.completeTransition(true)
                presentedView.hidden = false
                imageView.removeFromSuperview()
        }
    }
    
    private func animationForDismissView(transitionContext: UIViewControllerContextTransitioning) {
        guard let dismissDelegate = dismissDelegate, presentedDelegate = presentedDelegate else {
            return
        }
        
        // 1.取出小时的View
        let dismissView = transitionContext.viewForKey(UITransitionContextFromViewKey)
        dismissView?.removeFromSuperview()
        
        // 2.执行动画
        // 2.1.取出UIImageView
        let imageView = dismissDelegate.imageViewForDismissView()
        transitionContext.containerView()?.addSubview(imageView)
        let indexPath = dismissDelegate.indexPathForDismissView()
        
        // 2.2.执行动画
        UIView.animateWithDuration(transitionDuration(transitionContext), animations: { () -> Void in
            imageView.frame = presentedDelegate.startRectForIndexPath(indexPath)
            }) { (_) -> Void in
                imageView.removeFromSuperview()
                transitionContext.completeTransition(true)
        }
    }
}

