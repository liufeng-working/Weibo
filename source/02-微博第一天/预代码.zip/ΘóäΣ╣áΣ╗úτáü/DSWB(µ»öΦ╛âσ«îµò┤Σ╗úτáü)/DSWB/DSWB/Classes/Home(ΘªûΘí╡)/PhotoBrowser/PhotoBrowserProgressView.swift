//
//  PhotoBrowserProgressView.swift
//  DSWB
//
//  Created by apple on 16/3/20.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class PhotoBrowserProgressView: UIView {
    
    var progress : CGFloat = 0 {
        didSet {
            setNeedsDisplay()
        }
    }
    
    override func drawRect(rect: CGRect) {
        super.drawRect(rect)
        
        // 1.获取圆心
        let center = CGPoint(x: rect.width * 0.5, y: rect.height * 0.5)
        let radius = rect.width * 0.5 - 8
        let startAngle = CGFloat(-M_PI_2)
        let endAngle = CGFloat(M_PI * 2) * progress + startAngle
        
        // 2.创建贝塞尔曲线
        let bezierPath = UIBezierPath(arcCenter: center, radius: radius, startAngle: startAngle, endAngle: endAngle, clockwise: true)
        
        // 3.添加到中心线
        bezierPath.addLineToPoint(center)
        bezierPath.closePath()
        
        // 4.画出内容
        UIColor(white: 1.0, alpha: 0.2).setFill()
        bezierPath.fill()
        
        // 5.画边界的圆
        let closePath = UIBezierPath(arcCenter: center, radius: radius + 5, startAngle: startAngle, endAngle: CGFloat(M_PI * 2) + startAngle, clockwise: true)
        
        UIColor(white: 1.0, alpha: 0.2).setStroke()
        closePath.stroke()
    }
}
