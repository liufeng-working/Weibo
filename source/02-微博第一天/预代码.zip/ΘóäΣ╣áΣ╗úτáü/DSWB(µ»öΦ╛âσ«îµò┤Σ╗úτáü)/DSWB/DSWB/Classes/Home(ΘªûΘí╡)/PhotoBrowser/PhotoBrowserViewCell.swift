//
//  PhotoBrowserViewCell.swift
//  DSWB
//
//  Created by apple on 16/3/20.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit
import SDWebImage

protocol PhotoBrowserViewCellDelegate : NSObjectProtocol {
    func imageViewClick(cell : PhotoBrowserViewCell)
}

class PhotoBrowserViewCell: UICollectionViewCell {
    
    // MARK:- 定义模型属性
    var delegate : PhotoBrowserViewCellDelegate?
    
    var picURL : NSURL? {
        didSet {
            // 1.空值校验
            guard let picURL = picURL else {
                return
            }
            
            // 2.设置界面的内容
            setupUIContent(picURL)
        }
    }
    
    // MARK:- 懒加载属性
    lazy var scrollView : UIScrollView = UIScrollView()
    lazy var imageView : UIImageView = UIImageView()
    private lazy var progressView : PhotoBrowserProgressView = PhotoBrowserProgressView()
    
    // MARK:- 构造函数
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        setupUI()
    }
}


// MARK:- 设置UI界面
extension PhotoBrowserViewCell {
    private func setupUI() {
        // 1.添加子控件
        contentView.addSubview(scrollView)
        contentView.addSubview(progressView)
        scrollView.addSubview(imageView)
        
        // 2.设置控件的位置和尺寸
        scrollView.frame = contentView.bounds
        scrollView.frame.size.width -= 20
        progressView.bounds = CGRect(x: 0, y: 0, width: 50, height: 50)
        progressView.center = CGPoint(x: UIScreen.mainScreen().bounds.width * 0.5, y: UIScreen.mainScreen().bounds.height * 0.5)
        progressView.backgroundColor = UIColor.clearColor()
        progressView.hidden = true
        
        // 3.设置缩放的比例
        scrollView.delegate = self
        scrollView.maximumZoomScale = 2.0
        scrollView.minimumZoomScale = 0.5
        
        // 4.给imageView添加监听手势
        let tapGest = UITapGestureRecognizer(target: self, action: "imageViewClick")
        imageView.addGestureRecognizer(tapGest)
        imageView.userInteractionEnabled = true
    }
    
    @objc private func imageViewClick() {
        delegate?.imageViewClick(self)
    }
}


// MARK:- 设置UI内容
extension PhotoBrowserViewCell {
    private func setupUIContent(picURL : NSURL) {
        // 1.取出图片
        let image = SDWebImageManager.sharedManager().imageCache.imageFromMemoryCacheForKey(picURL.absoluteString)
        
        // 2.获取图片高度
        let screenW = UIScreen.mainScreen().bounds.width
        let screenH = UIScreen.mainScreen().bounds.height
        let imageViewH = screenW / image.size.width * image.size.height
        imageView.frame = CGRect(x: 0, y: 0, width: screenW, height: imageViewH)
        
        // 3.判断是长图还是短图
        if imageViewH > screenH {
            scrollView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        } else {
            let imageViewY = (screenH - imageViewH) * 0.5
            scrollView.contentInset = UIEdgeInsets(top: imageViewY, left: 0, bottom: 0, right: 0)
        }
        
        scrollView.contentSize = CGSize(width: 0, height: imageViewH)
        
        // 4.设置图片
        imageView.image = image
        
        // 5.下载大图
        // 5.1.获取大图的名称
        let bigPicURL = getBigURL(picURL)
        
        // 5.2.下载大图
        progressView.hidden = false
        imageView.sd_setImageWithURL(bigPicURL, placeholderImage: image, options: [], progress: { (current, total) -> Void in
                self.progressView.progress = CGFloat(current) / CGFloat(total)
            }) { (_, _, _, _) -> Void in
                self.progressView.hidden = true
        }
    }
    
    private func getBigURL(smallURL : NSURL) -> NSURL? {
        // 1.获取小图的字符串
        let smallURLString = smallURL.absoluteString
        
        // 2.获取大图的字符串
        let bigURLString = (smallURLString as NSString).stringByReplacingOccurrencesOfString("thumbnail", withString: "bmiddle")
        
        return NSURL(string: bigURLString)
    }
}


// MARK:- 设置scrollview的缩放
extension PhotoBrowserViewCell : UIScrollViewDelegate {
    func viewForZoomingInScrollView(scrollView: UIScrollView) -> UIView? {
        return imageView
    }
    
    func scrollViewDidEndZooming(scrollView: UIScrollView, withView view: UIView?, atScale scale: CGFloat) {
        var topInset = (scrollView.bounds.height - view!.frame.size.height) * 0.5
        topInset = topInset < 0 ? 0 : topInset
        
        var leftInset = (scrollView.bounds.width - view!.frame.size.width) * 0.5
        leftInset = leftInset < 0 ? 0 : leftInset
        
        scrollView.contentInset = UIEdgeInsets(top: topInset, left: leftInset, bottom: 0, right: 0)
    }
}