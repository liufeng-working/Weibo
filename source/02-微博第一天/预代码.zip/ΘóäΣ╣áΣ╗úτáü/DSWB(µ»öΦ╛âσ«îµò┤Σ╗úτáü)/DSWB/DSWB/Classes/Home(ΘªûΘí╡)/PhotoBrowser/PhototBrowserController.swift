//
//  PhototBrowserController.swift
//  DSWB
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit
import SnapKit
import SVProgressHUD

private let PhotoBrowserCellID = "PhotoBrowserCellID"

class PhototBrowserController: UIViewController {
    // MARK:- 属性
    var indexPath : NSIndexPath
    var picURLs : [NSURL]
    
    // MARK:- 懒加载属性
    private lazy var collectionView : UICollectionView = UICollectionView(frame: CGRectZero, collectionViewLayout: PhototBrowserCollectionViewLayout())
    private lazy var closeBtn : UIButton = UIButton(title: "关闭", bgColor: UIColor.darkGrayColor(), fontSize: 14)
    private lazy var saveBtn : UIButton = UIButton(title: "保存", bgColor: UIColor.darkGrayColor(), fontSize: 14)
    
    // MARK:- 自定义构造函数
    init (indexPath : NSIndexPath, picURLs : [NSURL]) {
        self.indexPath = indexPath
        self.picURLs = picURLs
        
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    // MARK:- 系统回调函数
    override func loadView() {
        super.loadView()
        
        view.frame.size.width += 20
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 设置UI界面
        setupUI()
        
        // 默认滚到indexPath位置
        collectionView.scrollToItemAtIndexPath(indexPath, atScrollPosition: .Left, animated: false)
    }
}


// MARK:- 设置UI界面
extension PhototBrowserController {
    private func setupUI() {
        // 1.添加子控件
        view.addSubview(collectionView)
        view.addSubview(closeBtn)
        view.addSubview(saveBtn)
        
        // 2.设置位置和尺寸
        collectionView.frame = view.bounds
        closeBtn.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(20)
            make.bottom.equalTo(-20)
            make.height.equalTo(32)
            make.width.equalTo(90)
        }
        saveBtn.snp_makeConstraints { (make) -> Void in
            make.right.equalTo(-20)
            make.bottom.equalTo(closeBtn.snp_bottom)
            make.size.equalTo(closeBtn.snp_size)
        }
        
        // 3.设置控件属性
        collectionView.dataSource = self
        collectionView.registerClass(PhotoBrowserViewCell.self, forCellWithReuseIdentifier: PhotoBrowserCellID)
        closeBtn.addTarget(self, action: "closeBtnClick", forControlEvents: .TouchUpInside)
        saveBtn.addTarget(self, action: "saveBtnClick", forControlEvents: .TouchUpInside)
    }
}

extension PhototBrowserController : PhotoBrowserDismissDelegate {
    func imageViewForDismissView() -> UIImageView {
        // 1.创建UIImage对象
        let imageView = UIImageView()
        
        // 2.设置属性
        imageView.contentMode = .ScaleAspectFill
        imageView.clipsToBounds = true
        
        // 3.设置frame
        let cell = collectionView.visibleCells().first as! PhotoBrowserViewCell
        imageView.image = cell.imageView.image
        imageView.frame = cell.scrollView.convertRect(cell.imageView.frame, toCoordinateSpace: UIApplication.sharedApplication().keyWindow!)
        
        return imageView
    }
    
    func indexPathForDismissView() -> NSIndexPath {
        // 1.取出正在显示的cell
        let cell = collectionView.visibleCells().first!
        
        // 2.取出该cell所在的下标值
        return collectionView.indexPathForCell(cell)!
    }
}

// MARK:- 事件监听
extension PhototBrowserController {
    @objc private func closeBtnClick() {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @objc private func saveBtnClick() {
        // 1.获取当前显示的cell
        guard let cell = collectionView.visibleCells()[0] as? PhotoBrowserViewCell else {
            return
        }
        
        // 2.取出cell的imageView中的图片
        guard let image = cell.imageView.image else {
            return
        }
        
        // 3.保存照片
        UIImageWriteToSavedPhotosAlbum(image, self, "image:didFinishSavingWithError:contextInfo:", nil)
    }
    
    // - (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo;
    @objc private func image(image : UIImage, didFinishSavingWithError error : NSError?, contextInfo context : AnyObject) {
        // 1.获取信息
        let message = error != nil ? "保存失败" : "保存成功"
        
        // 2.给用户提示
        SVProgressHUD.showInfoWithStatus(message)
    }
}


// MARK:- 实现collectionView的数据源和代理方法
extension PhototBrowserController : UICollectionViewDataSource {
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return picURLs.count
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        // 1.创建cell
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(PhotoBrowserCellID, forIndexPath: indexPath) as! PhotoBrowserViewCell
        
        // 2.设置背景
        cell.picURL = picURLs[indexPath.item]
        cell.delegate = self
        
        return cell
    }
}

extension PhototBrowserController : PhotoBrowserViewCellDelegate {
    func imageViewClick(cell: PhotoBrowserViewCell) {
        closeBtnClick()
    }
}

class PhototBrowserCollectionViewLayout : UICollectionViewFlowLayout {
    override func prepareLayout() {
        super.prepareLayout()
        
        // 1.设置布局属性
        itemSize = collectionView!.bounds.size
        minimumInteritemSpacing = 0
        minimumLineSpacing = 0
        scrollDirection = .Horizontal
        
        // 2.设置collectionView的属性
        collectionView?.showsHorizontalScrollIndicator = false
        collectionView?.pagingEnabled = true
    }
}