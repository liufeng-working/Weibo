//
//  PicCollectionView.swift
//  DSWB
//
//  Created by apple on 16/3/16.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit
import SDWebImage

private let padding : CGFloat = 10


class PicCollectionView: UICollectionView {
    // MARK:- 约束属性
    @IBOutlet weak var picViewLeftCons: NSLayoutConstraint!
    @IBOutlet weak var picViewHeightCons: NSLayoutConstraint!
    
    // MARK:- 属性
    var picURLs : [NSURL] = [NSURL]() {
        didSet {
            // 1.计算collectionView的右侧和高度约束
            let (height, right) = calculatePicViewCons(picURLs.count)
            picViewLeftCons.constant = right
            picViewHeightCons.constant = height
            
            // 2.设置布局
            setupLayut()
            
            // 3.刷新表格
            reloadData()
        }
    }
    
    // MARK:- 系统回调函数
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // 1.设置collectionView的属性
        self.dataSource = self
        self.delegate = self
    }
}

extension PicCollectionView {
    /// 设置layout布局
    private func setupLayut() {
        // 1.计算itemSize
        var itemSize = CGSizeZero
        if picURLs.count == 1 {
            let image = SDWebImageManager.sharedManager().imageCache.imageFromDiskCacheForKey(picURLs.first!.absoluteString)
            itemSize = CGSize(width: image.size.width * 2, height: image.size.height * 2)
        } else {
            let imageWH = (UIScreen.mainScreen().bounds.width - 2 * leftMargin - 2 * padding) / 3
            itemSize = CGSizeMake(imageWH, imageWH)
        }
        
        // 2.取出layout
        let layout = self.collectionViewLayout as! UICollectionViewFlowLayout
        layout.itemSize = itemSize
        layout.minimumInteritemSpacing = padding
        layout.minimumLineSpacing = padding
    }
    
    /// 计算图片View的左侧和高度约束
    private func calculatePicViewCons(count : Int) -> (CGFloat, CGFloat) {
        // 计算宽度和高度
        let imageWH = (UIScreen.mainScreen().bounds.width - 2 * leftMargin - 2 * padding) / 3
        
        // 没有图片
        if count == 0 {
            return (0, leftMargin)
        }
        
        
        // 一张图片
        if count == 1 {
            let image = SDWebImageManager.sharedManager().imageCache.imageFromDiskCacheForKey(picURLs.first!.absoluteString)
            let rightMargin = UIScreen.mainScreen().bounds.width - leftMargin - image.size.width * 2 - padding
            
            return (image.size.height * 2, rightMargin)
        }
        
        // 四张图片
        if count == 4 {
            let height = imageWH * 2 + padding
            let right = UIScreen.mainScreen().bounds.width - leftMargin - padding - 2 * imageWH - 1
            
            return (height, right)
        }
        
        // 其他图片
        let row = CGFloat((count - 1) / 3 + 1)
        let height = row * imageWH + (row - 1) * padding
        let right = leftMargin
        return (height, right)
    }
}

extension PicCollectionView : UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return picURLs.count
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        // 1.取出cell
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("picCellID", forIndexPath: indexPath) as! PicCollectionViewCell
        
        // 2.给cell设置数据
        cell.picURL = picURLs[indexPath.item]
        
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        // 1.获取发送通知需要携带的信息
        let userInfo = [showPhotoBrowserNotificationURLs : picURLs, showPhotoBrowserNotificationIndexPath : indexPath]
        
        // 2.发出通知
        NSNotificationCenter.defaultCenter().postNotificationName(showPhotoBrowserNotification, object: self, userInfo: userInfo)
    }
}


extension PicCollectionView : PhotoBrowserPresentedDelegate {
    func startRectForIndexPath(indexPath: NSIndexPath) -> CGRect {
        // 1.根据indexPath取出cell
        let cell = self.cellForItemAtIndexPath(indexPath)!
        
        // 2.取出cell相当于window的位置
        let frame = self.convertRect(cell.frame, toCoordinateSpace: UIApplication.sharedApplication().keyWindow!)
        
        return frame
    }
    
    func endRectForIndexPath(indexPath: NSIndexPath) -> CGRect {
        // 1.取出image
        let picURL = picURLs[indexPath.item]
        let image = SDWebImageManager.sharedManager().imageCache.imageFromDiskCacheForKey(picURL.absoluteString)
        
        // 2.计算image放大之后的高度
        let screenW = UIScreen.mainScreen().bounds.width
        let screenH = UIScreen.mainScreen().bounds.height
        let imageH = screenW / image.size.width * image.size.height
        
        // 3.判断高度是否大于屏幕的高度
        var endFrame = CGRectZero
        if imageH < screenH {
            let imageY = (screenH - imageH) * 0.5
            endFrame = CGRect(x: 0, y: imageY, width: screenW, height: imageH)
        } else {
            endFrame = CGRect(x: 0, y: 0, width: screenW, height: imageH)
        }
        
        return endFrame
    }
    
    func imageViewForIndexPath(indexPath: NSIndexPath) -> UIImageView {
        // 1.创建UIImageView对象
        let imageView = UIImageView()
        
        // 2.设置imageView的属性
        imageView.contentMode = .ScaleAspectFill
        
        // 3.设置图片
        let picURL = picURLs[indexPath.item]
        let image = SDWebImageManager.sharedManager().imageCache.imageFromDiskCacheForKey(picURL.absoluteString)
        imageView.image = image
        
        return imageView
    }
}


// MARK:- 自定义PicCollectionViewCell
class PicCollectionViewCell : UICollectionViewCell {
    // MARK:- 定义属性
    var picURL : NSURL? {
        didSet {
            picImageView.sd_setImageWithURL(picURL, placeholderImage: UIImage(named: "empty_picture"))
        }
    }
    
    // MARK:- 控件属性
    @IBOutlet weak var picImageView: UIImageView!
}
