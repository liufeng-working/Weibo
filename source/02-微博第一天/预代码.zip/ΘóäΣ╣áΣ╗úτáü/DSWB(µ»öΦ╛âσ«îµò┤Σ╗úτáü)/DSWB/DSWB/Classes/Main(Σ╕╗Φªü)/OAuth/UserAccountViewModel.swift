//
//  UserAccountViewModel.swift
//  DSWB
//
//  Created by apple on 16/3/13.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class UserAccountViewModel {
    
    typealias SuccessCallBack = (isSuccess : Bool) -> ()
    
    // 将类设计成单例
    static let shareIntance : UserAccountViewModel = UserAccountViewModel()
    
    /// 用户账号的模型对象
    var userAccount : UserAccount?
    
    /// 判断accessToken是否过期
    var isExpires : Bool {
        guard let expireDate = userAccount?.expires_date else {
            return true
        }
        
        return expireDate.compare(NSDate()) != NSComparisonResult.OrderedDescending
    }
    
    /// 判断是否登录
    var isLogin : Bool {
        return userAccount != nil && !isExpires
    }
    
    /// 沙盒路径
    var accountPath : String {
        let path = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true).first!
        return (path as NSString).stringByAppendingPathComponent("account.plist")
    }
    
    // MARK:- 构造函数
    init () {
        // 从沙盒读取用户账号
        userAccount = NSKeyedUnarchiver.unarchiveObjectWithFile(accountPath) as? UserAccount
    }
}

extension UserAccountViewModel {
    /// 加载accessToken
    func loadAccessToken(codeString : String, isSuccess : SuccessCallBack) {
        NetworkTools.shareIntance.loadAccessToken(codeString) { (result, error) -> () in
            // 1.错误校验
            if error != nil {
                print(error)
                isSuccess(isSuccess: false)
                return
            }
            
            // 2.获取结果,并且将结果转成模型对象
            guard let accountDict = result else {
                print("没有获取到账号信息")
                isSuccess(isSuccess: false)
                return
            }
            
            // 3.将字典转成模型对象
            let account = UserAccount(dict: accountDict)
            
            // 4.加载用户的信息
            self.loadUserInfo(account, isSuccess: isSuccess)
        }
    }
    
    /// 加载用户信息
    func loadUserInfo(account : UserAccount, isSuccess : SuccessCallBack) {
        // 1.判断accessToken和uid是否有值
        guard let accessToken = account.access_token, uid = account.uid else {
            isSuccess(isSuccess: false)
            return
        }
        
        // 2.发送网络请求
        NetworkTools.shareIntance.loadUserInfo(accessToken, uid: uid) { (result, error) -> () in
            // 2.1.错误校验
            if error != nil {
                print(error)
                isSuccess(isSuccess: false)
                return
            }
            
            // 2.2.判断字典是否有值
            guard let userInfoDict = result else {
                print("没有获取到用户信息")
                isSuccess(isSuccess: false)
                return
            }
            
            // 2.3.获取用户的昵称和头像
            account.avatar_large = userInfoDict["avatar_large"] as? String
            account.screen_name = userInfoDict["screen_name"] as? String
            
            // 2.4.将对象归档
            NSKeyedArchiver.archiveRootObject(account, toFile: self.accountPath)
            self.userAccount = account
            
            // 2.5.成功加载个人信息
            isSuccess(isSuccess: true)
        }
    }
}
