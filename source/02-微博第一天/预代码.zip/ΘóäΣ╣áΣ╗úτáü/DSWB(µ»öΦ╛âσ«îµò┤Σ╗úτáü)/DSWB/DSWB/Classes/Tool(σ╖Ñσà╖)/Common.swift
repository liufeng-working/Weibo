//
//  Common.swift
//  DSWB
//
//  Created by apple on 16/3/13.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

// 授权常量
let app_key = "333431233"
let app_secret = "083aa7acb0245b2aa141a2c85ed51860"
let redirect_uri = "http://www.520it.com"


// 界面常量
let leftMargin : CGFloat = 15



// 通知常量
let showPhotoBrowserNotification = "showPhotoBrowserNotification"
let showPhotoBrowserNotificationURLs = "showPhotoBrowserNotificationURLs"
let showPhotoBrowserNotificationIndexPath = "showPhotoBrowserNotificationIndexPath"