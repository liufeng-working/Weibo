//
//  NetworkTools.swift
//  10-AFNetwork的封装
//
//  Created by apple on 16/3/12.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import AFNetworking

enum XMGMethodType : String {
    case GET = "GET"
    case POST = "POST"
}

class NetworkTools: AFHTTPSessionManager {
    // 设计成单例
    static let shareIntance : NetworkTools = {
        let tools = NetworkTools()
        tools.responseSerializer.acceptableContentTypes?.insert("text/plain")
        return tools
    }()
    
    // 定义闭包别名
    typealias Finished = (result : [String : AnyObject]?, error : NSError?) -> ()
}


// MARK:- 网络请求的封装
extension NetworkTools {
    func request(methodType : XMGMethodType , urlString : String, parameters : [String : AnyObject], finished : (result : AnyObject?, error : NSError?) -> ()) {
        
        // 1.封装成功的回调
        let successCallBack = { (task : NSURLSessionDataTask, result : AnyObject?) -> Void in
            finished(result: result, error: nil)
        }
        
        // 2.封装失败的回调
        let failureCallBack = { (task : NSURLSessionDataTask?, error : NSError) -> Void in
            finished(result: nil, error: error)
        }
        
        // 3.发送网络请求
        if methodType == .GET {
            GET(urlString, parameters: parameters, progress: nil, success: successCallBack, failure: failureCallBack)
        } else {
            POST(urlString, parameters: parameters, progress: nil, success: successCallBack, failure: failureCallBack)
        }
    }
}


// MARK:- 加载accessToken
extension NetworkTools {
    func loadAccessToken(codeString : String, finished : Finished) {
        // 1.获取请求的URl
        let urlString = "https://api.weibo.com/oauth2/access_token"
        
        // 2.获取请求的参数
        let parameters = ["client_id" : app_key, "client_secret" : app_secret, "grant_type" : "authorization_code", "code" : codeString, "redirect_uri" : redirect_uri]
        
        // 3.发送网络请求
        request(.POST, urlString: urlString, parameters: parameters) { (result, error) -> () in
            finished(result: result as? [String : AnyObject], error: error)
        }
    }
}


// MARK:- 加载用户信息
extension NetworkTools {
    func loadUserInfo(accessToken : String, uid : String, finished : Finished) {
        // 1.获取请求的URLString
        let urlString = "https://api.weibo.com/2/users/show.json"
        
        // 2.获取请求的参数
        let parameters = ["access_token" : accessToken, "uid" : uid]
        
        // 3.发送网络请求
        request(.GET, urlString: urlString, parameters: parameters) { (result, error) -> () in
            finished(result: result as? [String : AnyObject], error: error)
        }
    }
}


// MARK:- 加载首页微博
extension NetworkTools {
    func loadStatus(sinceID : Int, maxID : Int, finished : (results : [[String : AnyObject]]?, error : NSError?) -> ()) {
        // 1.获取URLString
        let urlString = "https://api.weibo.com/2/statuses/home_timeline.json"
        
        // 2.获取请求参数)
        guard let accessToken = UserAccountViewModel.shareIntance.userAccount?.access_token else {
            return
        }
        let parameters = ["access_token" : accessToken, "since_id" : "\(sinceID)", "max_id" : "\(maxID)"]
        
        // 3.发送网络请求
        request(.GET, urlString: urlString, parameters: parameters) { (result, error) -> () in
            // 3.1.获取微博的结果字典
            guard let resultDict = result else {
                return
            }
            
            // 3.2.获取微博的字典数组
            guard let dictArray = resultDict["statuses"] as? [[String : AnyObject]] else {
                return
            }
            
            // 3.3.将获取到的内容回调到控制器中
            finished(results: dictArray, error: error)
        }
    }
}


// MARK:- 发送微博
extension NetworkTools {
    func sendStatus(statusText : String, image : UIImage?, isSuccess : (isSuccess : Bool) -> ()) {
        // 0.获取accessToken
        guard let accessToken = UserAccountViewModel.shareIntance.userAccount?.access_token else {
            return
        }
        
        // 1.获取请求参数
        let parameter = ["access_token" : accessToken, "status" : statusText]
        
        // 判断image是否有值
        if image == nil {
            // 2.获取URLString
            let urlString = "https://api.weibo.com/2/statuses/update.json"
            
            // 3.发送网络请求
            request(.POST, urlString: urlString, parameters: parameter) { (result, error) -> () in
                if error != nil {
                    isSuccess(isSuccess: false)
                    print(error)
                } else {
                    isSuccess(isSuccess: true)
                }
            }
        } else {
            // 2.获取URLString
            let urlString = "https://api.weibo.com/2/statuses/upload.json"
            
            // 3.发送网络请求
            POST(urlString, parameters: parameter, constructingBodyWithBlock: { (formData) -> Void in
                // 3.1.将image转成NSData类型
                if let imageData = UIImageJPEGRepresentation(image!, 0.2) {
                    formData.appendPartWithFileData(imageData, name: "pic", fileName: "123.png", mimeType: "image/png")
                }
                }, progress: nil, success: { (_, _) -> Void in
                    isSuccess(isSuccess: true)
                }, failure: { (_, error) -> Void in
                    print(error)
                    isSuccess(isSuccess: false)
            })
        }
    }
}
