//
//  ViewController.swift
//  02-异常的练习
//
//  Created by xiaomage on 16/4/5.
//  Copyright © 2016年 小码哥. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 正则表达式
        // 1.创建正则表达式的规则
        let pattern = "abc"
        
        // 2.创建正则表达式对象
        
        // 方式一:try方式
//        do {
//          let regex = try NSRegularExpression(pattern: pattern, options: .CaseInsensitive)
//        } catch {
//            print(error)
//        }
        
        // 方式二:try?方式
//        guard let regex = try? NSRegularExpression(pattern: pattern, options: .CaseInsensitive) else {
//            return
//        }
        
        
        // 方式三:try!方式(危险)
        let regex = try! NSRegularExpression(pattern: pattern, options: .CaseInsensitive)
    }
}













