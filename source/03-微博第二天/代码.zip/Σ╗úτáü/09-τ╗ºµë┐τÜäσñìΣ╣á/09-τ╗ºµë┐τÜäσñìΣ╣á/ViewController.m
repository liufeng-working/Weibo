//
//  ViewController.m
//  09-继承的复习
//
//  Created by xiaomage on 16/4/5.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "ViewController.h"
#import "Student.h"
#import "Teacher.h"
#import "Book.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    Student *stu = [[Student alloc] init];
    Teacher *tea = [[Teacher alloc] init];
    
    stu.book.name = @"笑傲江湖";
    
    NSLog(@"%@", stu.book.name);
    NSLog(@"%@", tea.book.name);
}

@end
