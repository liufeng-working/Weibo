//
//  MainViewController.swift
//  DSWB
//
//  Created by apple on 16/3/9.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class MainViewController: UITabBarController {
    // MARK:- 懒加载属性
    private lazy var imageNames : [String] = ["tabbar_home", "tabbar_message_center", "", "tabbar_discover", "tabbar_profile"]
    
    // MARK:- 系统回调函数
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        adjustItems()
    }
}

// MARK:- 设置UI
extension MainViewController {
    /// 调整items
    private func adjustItems() {
        /// 取出所有的item,并且设置图片
        for i in 0..<tabBar.items!.count {
            // 1.取出item
            let item = tabBar.items![i]
            
            // 2.如果是第二个,则不能和用户交互
            if i == 2 {
                item.enabled = false
                continue
            }
            
            // 3.设置item的图片
            item.selectedImage = UIImage(named: imageNames[i] + "_highlighted")
        }
    }
}
