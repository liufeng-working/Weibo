//
//  MainViewController.swift
//  DSWB
//
//  Created by apple on 16/3/9.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class MainViewController: UITabBarController {
    // MARK:- 懒加载属性
    private lazy var imageNames : [String] = ["tabbar_home", "tabbar_message_center", "", "tabbar_discover", "tabbar_profile"]
    private lazy var composeBtn : UIButton = UIButton()
    
    // MARK:- 系统回调函数
    override func viewDidLoad() {
        super.viewDidLoad()
        setupComposeBtn()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        adjustItems()
    }
}

// MARK:- 设置UI
extension MainViewController {
    /// 调整items
    private func adjustItems() {
        /// 取出所有的item,并且设置图片
        for i in 0..<tabBar.items!.count {
            // 1.取出item
            let item = tabBar.items![i]
            
            // 2.如果是第二个,则不能和用户交互
            if i == 2 {
                item.enabled = false
                continue
            }
            
            // 3.设置item的图片
            item.selectedImage = UIImage(named: imageNames[i] + "_highlighted")
        }
    }
    
    /// 添加发布按钮
    private func setupComposeBtn() {
        // 1.添加发布按钮
        tabBar.addSubview(composeBtn)
        
        // 2.设置属性
        composeBtn.setBackgroundImage(UIImage(named: "tabbar_compose_button"), forState: .Normal)
        composeBtn.setBackgroundImage(UIImage(named: "tabbar_compose_button_highlighted"), forState: .Highlighted)
        composeBtn.setImage(UIImage(named: "tabbar_compose_icon_add"), forState: .Normal)
        composeBtn.setImage(UIImage(named: "tabbar_compose_icon_add_highlighted"), forState: .Highlighted)
        
        // 3.设置位置和尺寸
        composeBtn.sizeToFit()
        composeBtn.center = CGPoint(x: tabBar.bounds.size.width * 0.5, y: tabBar.bounds.size.height * 0.5)
    }
}
