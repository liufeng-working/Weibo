//
//  HomeViewController.swift
//  DSWB
//
//  Created by apple on 16/3/9.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class HomeViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1.判断是否登录
        if !isLogin {
            visitorView.addRotationViewAnim()
            return
        }
        
        // 2.设置导航栏的内容
        setupNavigationItems()
    }
}


// MARK:- 设置导航栏的内容
extension HomeViewController {
    /// 设置导航栏的内容
    private func setupNavigationItems() {
        // 1.设置左侧导航栏的内容
        navigationItem.leftBarButtonItem = UIBarButtonItem(imageName: "navigationbar_friendattention")
        
        // 2.设置右侧导航栏的内容
        navigationItem.rightBarButtonItem = UIBarButtonItem(imageName: "navigationbar_pop")
    }
}