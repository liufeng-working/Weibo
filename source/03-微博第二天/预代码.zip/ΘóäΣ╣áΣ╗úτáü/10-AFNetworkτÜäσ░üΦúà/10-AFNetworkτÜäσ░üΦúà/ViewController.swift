//
//  ViewController.swift
//  10-AFNetwork的封装
//
//  Created by apple on 16/3/12.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        NetworkTools.shareIntance.request(.POST, urlString: "http://httpbin.org/post", parameters: ["name" : "why", "height" : 1.88]) { (result, error) -> () in
            if error != nil {
                print(error)
                return
            }
            
            print(result)
        }
    }
}

