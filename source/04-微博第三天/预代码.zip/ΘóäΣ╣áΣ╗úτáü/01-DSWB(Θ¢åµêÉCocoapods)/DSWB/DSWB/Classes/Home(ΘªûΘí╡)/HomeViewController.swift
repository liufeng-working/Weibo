//
//  HomeViewController.swift
//  DSWB
//
//  Created by apple on 16/3/9.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class HomeViewController: BaseViewController {
    
    // MARK:- 懒加载属性
    private lazy var titleBtn : UIButton = TitleButton(type: .Custom)
    private lazy var popoverAnimator = PopoverAnimator()
    
    // MARK:- 系统回调函数
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1.判断是否登录
        if !isLogin {
            visitorView.addRotationViewAnim()
            return
        }
        
        // 2.设置导航栏的内容
        setupNavigationItems()
    }
}


// MARK:- 设置导航栏的内容
extension HomeViewController {
    /// 设置导航栏的内容
    private func setupNavigationItems() {
        // 1.设置左侧导航栏的内容
        navigationItem.leftBarButtonItem = UIBarButtonItem(imageName: "navigationbar_friendattention")
        
        // 2.设置右侧导航栏的内容
        navigationItem.rightBarButtonItem = UIBarButtonItem(imageName: "navigationbar_pop")
        
        // 3.设置导航栏的标题
        titleBtn.setTitle("coderwhy", forState: .Normal)
        titleBtn.addTarget(self, action: "titleBtnClick:", forControlEvents: .TouchUpInside)
        navigationItem.titleView = titleBtn
    }
}


// MARK:- 事件监听函数
extension HomeViewController {
    /// 标题按钮的点击事件
    @objc private func titleBtnClick(titleBtn : TitleButton) {
        // 1.设置按钮的选中状态
        // titleBtn.selected = !titleBtn.selected
        
        // 2.创建PopoverVc
        let popoverVc = PopoverViewController()
        
        // 3.设置弹出样式是自定义(自定义时不会隐藏后面的控制器)
        popoverVc.modalPresentationStyle = .Custom
        
        // 4.设置转场动画的代理
        popoverAnimator.presentedFrame = CGRect(x: 100, y: 60, width: 180, height: 250)
        popoverAnimator.presentedCallBack = {[weak self] (isPresented) -> () in
            self?.titleBtn.selected = isPresented
        }
        popoverVc.transitioningDelegate = popoverAnimator
        
        // 弹出控制器
        presentViewController(popoverVc, animated: true, completion: nil)
    }
}
