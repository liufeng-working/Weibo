//
//  PopoverAnimator.swift
//  DSWB
//
//  Created by apple on 16/3/12.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class PopoverAnimator: NSObject {
    
    // MARK:- 属性
    private var isPresented : Bool = false
    var presentedFrame : CGRect = CGRectZero
    
    var presentedCallBack : ((isPresented : Bool) -> ())?
}

extension PopoverAnimator : UIViewControllerTransitioningDelegate {
    func presentationControllerForPresentedViewController(presented: UIViewController, presentingViewController presenting: UIViewController, sourceViewController source: UIViewController) -> UIPresentationController? {
        
        let presentationController = XMGPresentationController(presentedViewController: presented, presentingViewController: presenting)
        
        presentationController.presentedFrame = presentedFrame
        
        return presentationController
    }
    
    func animationControllerForPresentedController(presented: UIViewController, presentingController presenting: UIViewController, sourceController source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        
        isPresented = true
        if let presentedCallBack = presentedCallBack {
            presentedCallBack(isPresented : isPresented)
        }
        
        return self
    }
    
    func animationControllerForDismissedController(dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        
        isPresented = false
        if let presentedCallBack = presentedCallBack {
            presentedCallBack(isPresented : isPresented)
        }
        
        return self
    }
}

extension PopoverAnimator : UIViewControllerAnimatedTransitioning {
    func transitionDuration(transitionContext: UIViewControllerContextTransitioning?) -> NSTimeInterval {
        return 0.5
    }
    
    func animateTransition(transitionContext: UIViewControllerContextTransitioning) {
        // UITransitionContextFromViewKey : 如果是消失动画,则通过该key获取到View
        // UITransitionContextToViewKey : 如果是弹出动画,则通过该key获取到View
        
        isPresented ? presentedAnimation(transitionContext) : dismissAnimation(transitionContext)
    }
    
    
    // MARK:- 执行动画代码
    private func presentedAnimation(transitionContext : UIViewControllerContextTransitioning) {
        // 1.获取弹出的View
        let presentedView = transitionContext.viewForKey(UITransitionContextToViewKey)!
        
        // 2.将弹出的View添加到容器视图
        transitionContext.containerView()?.addSubview(presentedView)
        
        // 3.执行动画
        presentedView.layer.anchorPoint = CGPoint(x: 0.5, y: 0)
        presentedView.transform = CGAffineTransformMakeScale(1.0, 0)
        UIView.animateWithDuration(transitionDuration(transitionContext), animations: { () -> Void in
            presentedView.transform = CGAffineTransformIdentity
            }) { (_) -> Void in
                transitionContext.completeTransition(true)
        }
    }
    
    private func dismissAnimation(transitionContext : UIViewControllerContextTransitioning) {
        // 1.取出消失的View
        let dismissView = transitionContext.viewForKey(UITransitionContextFromViewKey)
        
        // 2.执行动画
        UIView.animateWithDuration(transitionDuration(transitionContext), animations: { () -> Void in
            dismissView?.transform = CGAffineTransformMakeScale(1.0, 0.00000001)
            }) { (_) -> Void in
                dismissView?.removeFromSuperview()
                transitionContext.completeTransition(true)
        }
    }
}

