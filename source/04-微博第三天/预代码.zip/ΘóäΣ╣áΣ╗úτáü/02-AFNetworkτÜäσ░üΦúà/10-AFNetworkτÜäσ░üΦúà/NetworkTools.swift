//
//  NetworkTools.swift
//  10-AFNetwork的封装
//
//  Created by apple on 16/3/12.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import AFNetworking

enum XMGMethodType : String {
    case GET = "GET"
    case POST = "POST"
}

class NetworkTools: AFHTTPSessionManager {
    // 设计成单例
    static let shareIntance : NetworkTools = NetworkTools()
}


// MARK:- 网络请求的封装
extension NetworkTools {
    func request(methodType : XMGMethodType , urlString : String, parameters : [String : AnyObject], finished : (result : AnyObject?, error : NSError?) -> ()) {
        
        // 1.封装成功的回调
        let successCallBack = { (task : NSURLSessionDataTask, result : AnyObject?) -> Void in
            finished(result: result, error: nil)
        }
        
        // 2.封装失败的回调
        let failureCallBack = { (task : NSURLSessionDataTask?, error : NSError) -> Void in
            finished(result: nil, error: error)
        }
        
        // 3.发送网络请求
        if methodType == .GET {
            GET(urlString, parameters: parameters, progress: nil, success: successCallBack, failure: failureCallBack)
        } else {
            POST(urlString, parameters: parameters, progress: nil, success: successCallBack, failure: failureCallBack)
        }
    }
}