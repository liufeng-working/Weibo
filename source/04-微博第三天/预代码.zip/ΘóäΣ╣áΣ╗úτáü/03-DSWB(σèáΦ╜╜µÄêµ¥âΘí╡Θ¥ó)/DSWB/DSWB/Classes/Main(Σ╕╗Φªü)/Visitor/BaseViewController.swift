//
//  BaseViewController.swift
//  DSWB
//
//  Created by apple on 16/3/12.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class BaseViewController: UITableViewController {
    
    // MARK:- 懒加载属性
    lazy var visitorView : VisitorView = VisitorView.visitorView()
    
    // MARK:- 属性
    var isLogin : Bool = false
    
    // MARK:- 系统回调函数
    override func loadView() {
        isLogin ? super.loadView() : setupVisitorView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

extension BaseViewController {
    private func setupVisitorView() {
        // 将访客视图作为根视图
        view = visitorView
        
        // 添加注册和登录的item
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "注册", style: .Plain, target: self, action: "registerBtnClick")
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "登录", style: .Plain, target: self, action: "loginBtnClick")
        
        // 监听访客视图中View的点击
        visitorView.registerBtn.addTarget(self, action: "registerBtnClick", forControlEvents: .TouchUpInside)
        visitorView.loginBtn.addTarget(self, action: "loginBtnClick", forControlEvents: .TouchUpInside)
    }
}


// MARK:- 事件监听函数
extension BaseViewController {
    @objc private func registerBtnClick() {
        print("registerBtnClick")
    }
    @objc private func loginBtnClick() {
        // 1.创建授权页面
        let oauthVc = OAuthViewController()
        
        // 2.包装导航控制器
        let oauthNav = UINavigationController(rootViewController: oauthVc)
        
        // 3.弹出授权页面
        presentViewController(oauthNav, animated: true, completion: nil)
    }
}
