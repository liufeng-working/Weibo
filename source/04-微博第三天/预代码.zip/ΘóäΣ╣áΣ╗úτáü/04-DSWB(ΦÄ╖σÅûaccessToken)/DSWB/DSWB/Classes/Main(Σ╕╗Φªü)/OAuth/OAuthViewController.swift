//
//  OAuthViewController.swift
//  DSWB
//
//  Created by apple on 16/3/12.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit
import SVProgressHUD

class OAuthViewController: UIViewController {
    // MARK:- 属性
    @IBOutlet weak var webView: UIWebView!
    
    // MARK:- 系统回调函数
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1.设置UI
        setupUI()
    }
}

// MARK:- 初始化UI
extension OAuthViewController {
    // 初始化UI
    private func setupUI() {
        // 1.设置导航栏内容
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "关闭", style: .Plain, target: self, action: "close")
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "填充", style: .Plain, target: self, action: "autoFill")
        navigationItem.title = "登录界面"
        
        // 2.设置加载页面
        webView.loadRequest(NSURLRequest(URL: NSURL(string: "https://api.weibo.com/oauth2/authorize?client_id=\(app_key)&redirect_uri=\(redirect_uri)")!))
    }
}


// MARK:- 事件监听
extension OAuthViewController {
    @objc private func close() {
        SVProgressHUD.dismiss()
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @objc private func autoFill() {
        // 1.获取js代码
        let jsCode = "document.getElementById('userId').value='1606020376@qq.com';document.getElementById('passwd').value='haomage';"
        
        // 2.执行js代码
        webView.stringByEvaluatingJavaScriptFromString(jsCode)
    }
}


// MARK:- UIWebViewDelegate
extension OAuthViewController : UIWebViewDelegate {
    func webViewDidStartLoad(webView: UIWebView) {
        SVProgressHUD.show()
    }
    
    func webViewDidFinishLoad(webView: UIWebView) {
        SVProgressHUD.dismiss()
    }
    
    func webView(webView: UIWebView, didFailLoadWithError error: NSError?) {
        SVProgressHUD.dismiss()
    }
    
    /// 当加载某一个页面时会执行该方法
    // 返回值 : 返回true,则继续加载.返回false,则停止加载
    func webView(webView: UIWebView, shouldStartLoadWithRequest request: NSURLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        
        // 1.获取URL的字符串
        guard let urlString = request.URL?.absoluteString else {
            print("没有获取到字符串")
            return true
        }
        
        // 2.判断是否有code,如果没有,则继续加载
        guard urlString.containsString("code=") else {
            return true
        }
        
        // 3.截取code
        guard let codeString = urlString.componentsSeparatedByString("code=").last else {
            print("没有获取到code")
            return true
        }
        
        // 4.用code换取accessToken
        loadAccessToken(codeString)
        
        return false
    }
}

// MARK:- 请求数据
extension OAuthViewController {
    /// 加载accessToken
    private func loadAccessToken(codeString : String) {
        NetworkTools.shareIntance.loadAccessToken(codeString) { (result, error) -> () in
            // 1.错误校验
            if error != nil {
                print(error)
                return
            }
            
            // 2.获取结果,并且将结果转成模型对象
            guard let accountDict = result else {
                print("没有获取到账号信息")
                return
            }
            
            // 3.将字典转成模型对象
            let account = UserAccount(dict: accountDict)
            
            // 4.加载用户的信息
            self.loadUserInfo(account)
        }
    }
    
    /// 加载用户信息
    private func loadUserInfo(account : UserAccount) {
        // 1.判断accessToken和uid是否有值
        guard let accessToken = account.access_token, uid = account.uid else {
            return
        }
        
        // 2.发送网络请求
        NetworkTools.shareIntance.loadUserInfo(accessToken, uid: uid) { (result, error) -> () in
            // 2.1.错误校验
            if error != nil {
                print(error)
                return
            }
            
            // 2.2.判断字典是否有值
            guard let userInfoDict = result else {
                print("没有获取到用户信息")
                return
            }
            
            // 2.3.获取用户的昵称和头像
            account.avatar_large = userInfoDict["avatar_large"] as? String
            account.screen_name = userInfoDict["screen_name"] as? String
            
            print(account)
        }
    }
}
