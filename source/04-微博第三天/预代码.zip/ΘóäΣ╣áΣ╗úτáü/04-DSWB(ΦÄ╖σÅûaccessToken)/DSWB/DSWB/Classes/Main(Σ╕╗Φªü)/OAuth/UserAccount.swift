//
//  UserAccount.swift
//  DSWB
//
//  Created by apple on 16/3/13.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class UserAccount: NSObject {
    // MARK:- 属性
    var access_token : String?
    var expires_in : NSTimeInterval = 0 {
        didSet {
            expires_date = NSDate(timeIntervalSinceNow: expires_in)
        }
    }
    var uid : String?
    var avatar_large : String?
    var screen_name : String?
    
    var expires_date : NSDate?
    
    // MARK:- 构造函数
    init(dict : [String : AnyObject]) {
        super.init()
        
        setValuesForKeysWithDictionary(dict)
    }
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {}
    override var description : String {
        return dictionaryWithValuesForKeys(["access_token", "expires_in", "uid", "expires_date", "avatar_large", "screen_name"]).description
    }
}
