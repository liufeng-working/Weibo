//
//  XMGPresentationController.swift
//  DSWB
//
//  Created by apple on 16/3/12.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class XMGPresentationController: UIPresentationController {
    
    var presentedFrame : CGRect = CGRectZero
    
    override func containerViewWillLayoutSubviews() {
        super.containerViewWillLayoutSubviews()
        
        // 1.设置弹出View的尺寸
        presentedView()?.frame = presentedFrame
        
        // 2.添加蒙版
        setupCoverView()
    }
}

extension XMGPresentationController {
    /// 添加蒙版
    private func setupCoverView() {
        // 1.创建蒙版
        let coverView = UIView(frame: containerView!.bounds)
        
        // 2.设置蒙版的颜色
        coverView.backgroundColor = UIColor(white: 0.7, alpha: 0.2)
        
        // 3.监听蒙版的点击
        let tapGes = UITapGestureRecognizer(target: self, action: "coverViewClick")
        coverView.addGestureRecognizer(tapGes)
        
        // 4.将蒙版添加到容器视图中
        containerView?.insertSubview(coverView, belowSubview: presentedView()!)
    }
    
    @objc private func coverViewClick() {
        presentedViewController.dismissViewControllerAnimated(true, completion: nil)
    }
}
