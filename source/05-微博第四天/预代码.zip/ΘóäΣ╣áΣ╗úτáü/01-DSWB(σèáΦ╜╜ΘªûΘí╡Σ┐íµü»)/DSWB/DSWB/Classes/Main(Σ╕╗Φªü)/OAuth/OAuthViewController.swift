//
//  OAuthViewController.swift
//  DSWB
//
//  Created by apple on 16/3/12.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit
import SVProgressHUD

class OAuthViewController: UIViewController {
    // MARK:- 属性
    @IBOutlet weak var webView: UIWebView!
    
    // MARK:- 系统回调函数
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1.设置UI
        setupUI()
    }
}

// MARK:- 初始化UI
extension OAuthViewController {
    // 初始化UI
    private func setupUI() {
        // 1.设置导航栏内容
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "关闭", style: .Plain, target: self, action: "close")
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "填充", style: .Plain, target: self, action: "autoFill")
        navigationItem.title = "登录界面"
        
        // 2.设置加载页面
        webView.loadRequest(NSURLRequest(URL: NSURL(string: "https://api.weibo.com/oauth2/authorize?client_id=\(app_key)&redirect_uri=\(redirect_uri)")!))
    }
}


// MARK:- 事件监听
extension OAuthViewController {
    @objc private func close() {
        SVProgressHUD.dismiss()
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @objc private func autoFill() {
        // 1.获取js代码
        let jsCode = "document.getElementById('userId').value='1606020376@qq.com';document.getElementById('passwd').value='haomage';"
        
        // 2.执行js代码
        webView.stringByEvaluatingJavaScriptFromString(jsCode)
    }
}


// MARK:- UIWebViewDelegate
extension OAuthViewController : UIWebViewDelegate {
    func webViewDidStartLoad(webView: UIWebView) {
        SVProgressHUD.show()
    }
    
    func webViewDidFinishLoad(webView: UIWebView) {
        SVProgressHUD.dismiss()
    }
    
    func webView(webView: UIWebView, didFailLoadWithError error: NSError?) {
        SVProgressHUD.dismiss()
    }
    
    /// 当加载某一个页面时会执行该方法
    // 返回值 : 返回true,则继续加载.返回false,则停止加载
    func webView(webView: UIWebView, shouldStartLoadWithRequest request: NSURLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        
        // 1.获取URL的字符串
        guard let urlString = request.URL?.absoluteString else {
            print("没有获取到字符串")
            return true
        }
        
        // 2.判断是否有code,如果没有,则继续加载
        guard urlString.containsString("code=") else {
            return true
        }
        
        // 3.截取code
        guard let codeString = urlString.componentsSeparatedByString("code=").last else {
            print("没有获取到code")
            return true
        }
        
        // 4.用code换取accessToken
        UserAccountViewModel.shareIntance.loadAccessToken(codeString) { (isSuccess) -> () in
            if isSuccess {
                self.dismissViewControllerAnimated(false, completion: { () -> Void in
                    UIApplication.sharedApplication().keyWindow?.rootViewController = WelcomeViewController()
                })
            }
        }
        
        return false
    }
}
