//
//  ViewController.swift
//  04-时间的处理
//
//  Created by apple on 16/3/15.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Tue Mar 15 15:51:53 +0800 2016
        let create_at = "Tue Mar 02 11:22:30 +0800 2014"
        
        print(NSDate.createTimeWithString(create_at))
    }
}

