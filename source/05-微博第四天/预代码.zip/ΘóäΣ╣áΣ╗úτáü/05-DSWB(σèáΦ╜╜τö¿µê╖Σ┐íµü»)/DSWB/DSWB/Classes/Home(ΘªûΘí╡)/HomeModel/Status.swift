//
//  Status.swift
//  DSWB
//
//  Created by apple on 16/3/15.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class Status: NSObject {
    // MARK:- 属性
    /// 创建时间
    var created_at : String?
    /// 微博ID
    var id : Int = 0
    /// 微博正文
    var text : String?
    /// 微博的来源
    var source : String? {
        didSet {
            // <a href=\"http://weibo.com/\" rel=\"nofollow\">微博 weibo.com</a>
            guard let source = source where source != "" else {
                return
            }
            // 1.获取其实位置
            let startIndex = (source as NSString).rangeOfString(">").location + 1
            
            // 2.获取截取的长度
            let length = (source as NSString).rangeOfString("</").location - startIndex
            
            // 3.获取来源的字符串
            sourceText = (source as NSString).substringWithRange(NSRange(location: startIndex, length: length))
        }
    }
    
    /// 创建时间的字符串显示
    var createAtText : String? {
        return NSDate.createTimeWithString(created_at ?? "")
    }
    /// 数据的来源处理
    var sourceText : String?
    
    /// 用户属性
    var user : User?
    
    // MARK:- 构造函数
    init(dict : [String : AnyObject]) {
        super.init()
        setValuesForKeysWithDictionary(dict)
        
        if let userDict = dict["user"] as? [String : AnyObject] {
            user = User(dict: userDict)
        }
    }
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {}
}
