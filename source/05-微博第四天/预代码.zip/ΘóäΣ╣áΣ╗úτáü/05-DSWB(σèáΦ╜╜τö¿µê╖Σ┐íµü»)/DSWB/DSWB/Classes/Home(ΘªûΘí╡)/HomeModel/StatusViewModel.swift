//
//  StatusViewModel.swift
//  DSWB
//
//  Created by apple on 16/3/15.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class StatusViewModel {
    // MARK:- 属性
    var status : Status?
    
    /// 微博创建时间
    
    /// 微博来源
    
    /// 会员等级
    
    /// 认证类型
    
    // MARK:- 构造函数
    init (status : Status) {
        self.status = status
    }
}
