//
//  HomeViewCell.swift
//  DSWB
//
//  Created by apple on 16/3/15.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit
import SDWebImage

class HomeViewCell: UITableViewCell {
    // MARK:- 控件属性
    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var screenNameLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var sourceLabel: UILabel!
    @IBOutlet weak var verifiedImageView: UIImageView!
    @IBOutlet weak var vipImageView: UIImageView!
    @IBOutlet weak var contentLabel: UILabel!
    
    // MARK:- 模型对象
    var statusViewModel : StatusViewModel? {
        didSet {
            // 1.nil值校验
            guard let statusViewModel = statusViewModel else {
                return
            }
            
            // 2.设置头像
            iconImageView.sd_setImageWithURL(statusViewModel.profileURL, placeholderImage: UIImage(named: "avatar_default"))
            
            // 3.设置昵称
            screenNameLabel.text = statusViewModel.status?.user?.screen_name
            
            // 4.设置时间
            timeLabel.text = statusViewModel.createAtText
            
            // 5.设置来源
            sourceLabel.text = statusViewModel.sourceText
            
            // 6.设置认证图片
            verifiedImageView.image = statusViewModel.verifiedImage
            
            // 7.设置会员图片
            vipImageView.image = statusViewModel.mbRankImage
            
            // 8.设置昵称的颜色
            screenNameLabel.textColor = statusViewModel.mbRankImage != nil ? UIColor.orangeColor() : UIColor.blackColor()
            
            // 9.设置微博正文
            contentLabel.text = statusViewModel.status?.text
        }
    }
}
