//
//  HomeViewCell.swift
//  DSWB
//
//  Created by apple on 16/3/15.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit
import SDWebImage

private let leftMargin : CGFloat = 15
private let padding : CGFloat = 10

class HomeViewCell: UITableViewCell {
    // MARK:- 控件属性
    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var screenNameLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var sourceLabel: UILabel!
    @IBOutlet weak var verifiedImageView: UIImageView!
    @IBOutlet weak var vipImageView: UIImageView!
    @IBOutlet weak var contentLabel: UILabel!
    @IBOutlet weak var bottomToolView: UIView!
    @IBOutlet weak var picCollectionView: PicCollectionView!
    
    // MARK:- 约束属性
    @IBOutlet weak var picViewLeftCons: NSLayoutConstraint!
    @IBOutlet weak var picViewHeightCons: NSLayoutConstraint!
    @IBOutlet weak var contentLabelWidthCons: NSLayoutConstraint!
    
    
    // MARK:- 模型对象
    var statusViewModel : StatusViewModel? {
        didSet {
            // 1.nil值校验
            guard let statusViewModel = statusViewModel else {
                return
            }
            
            // 2.设置头像
            iconImageView.sd_setImageWithURL(statusViewModel.profileURL, placeholderImage: UIImage(named: "avatar_default"))
            
            // 3.设置昵称
            screenNameLabel.text = statusViewModel.status?.user?.screen_name
            
            // 4.设置时间
            timeLabel.text = statusViewModel.createAtText
            
            // 5.设置来源
            sourceLabel.text = statusViewModel.sourceText
            
            // 6.设置认证图片
            verifiedImageView.image = statusViewModel.verifiedImage
            
            // 7.设置会员图片
            vipImageView.image = statusViewModel.mbRankImage
            
            // 8.设置昵称的颜色
            screenNameLabel.textColor = statusViewModel.mbRankImage != nil ? UIColor.orangeColor() : UIColor.blackColor()
            
            // 9.设置微博正文
            contentLabel.text = statusViewModel.status?.text
            
            // 10.计算图片的View的右侧和高度约束
            let (height, right) = calculatePicViewCons(statusViewModel.picURLs.count)
            picViewHeightCons.constant = height
            picViewLeftCons.constant = right
            
            // 11.给collectionView赋值数据
            picCollectionView.picURLs = statusViewModel.picURLs
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        contentLabelWidthCons.constant = UIScreen.mainScreen().bounds.width - 2 * leftMargin
    }
}


extension HomeViewCell {
    /// 计算图片View的左侧和高度约束
    private func calculatePicViewCons(count : Int) -> (CGFloat, CGFloat) {
        // 计算宽度和高度
        let imageWH = (UIScreen.mainScreen().bounds.width - 2 * leftMargin - 2 * padding) / 3
        
        // 没有图片
        if count == 0 {
            return (0, leftMargin)
        }
        
        // 四张图片
        if count == 4 {
            let height = imageWH * 2 + padding
            let right = UIScreen.mainScreen().bounds.width - leftMargin - padding - 2 * imageWH
            
            return (height, right)
        }
        
        // 其他图片
        let row = CGFloat((count - 1) / 3 + 1)
        let height = row * imageWH + (row - 1) * padding
        let right = leftMargin
        return (height, right)
    }
    
    /// 计算cell的高度
    func calculateCellHeight(statusViewModel : StatusViewModel) -> CGFloat {
        // 1.给成员属性赋值
        self.statusViewModel = statusViewModel
        
        // 2.更新约束
        layoutIfNeeded()
        
        // 3.返回工具栏的最大y值
        return CGRectGetMaxY(bottomToolView.frame)
    }
}
