//
//  HomeViewController.swift
//  DSWB
//
//  Created by apple on 16/3/9.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit
import SDWebImage

class HomeViewController: BaseViewController {
    // MARK:- 模型属性
    private lazy var statusViewModels : [StatusViewModel] = [StatusViewModel]()
    
    // MARK:- 懒加载属性
    private lazy var titleBtn : UIButton = TitleButton(type: .Custom)
    private lazy var popoverAnimator = PopoverAnimator()
    private lazy var cellHeightCache : [String : CGFloat] = [String : CGFloat]()
    
    // MARK:- 系统回调函数
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1.判断是否登录
        if !isLogin {
            visitorView.addRotationViewAnim()
            return
        }
        
        // 2.设置导航栏的内容
        setupNavigationItems()
        
        // 3.加载首页微博
        loadStatus()
    }
}


// MARK:- 设置导航栏的内容
extension HomeViewController {
    /// 设置导航栏的内容
    private func setupNavigationItems() {
        // 1.设置左侧导航栏的内容
        navigationItem.leftBarButtonItem = UIBarButtonItem(imageName: "navigationbar_friendattention")
        
        // 2.设置右侧导航栏的内容
        navigationItem.rightBarButtonItem = UIBarButtonItem(imageName: "navigationbar_pop")
        
        // 3.设置导航栏的标题
        titleBtn.setTitle("coderwhy", forState: .Normal)
        titleBtn.addTarget(self, action: "titleBtnClick:", forControlEvents: .TouchUpInside)
        navigationItem.titleView = titleBtn
    }
}


// MARK:- 事件监听函数
extension HomeViewController {
    /// 标题按钮的点击事件
    @objc private func titleBtnClick(titleBtn : TitleButton) {
        // 1.设置按钮的选中状态
        // titleBtn.selected = !titleBtn.selected
        
        // 2.创建PopoverVc
        let popoverVc = PopoverViewController()
        
        // 3.设置弹出样式是自定义(自定义时不会隐藏后面的控制器)
        popoverVc.modalPresentationStyle = .Custom
        
        // 4.设置转场动画的代理
        popoverAnimator.presentedFrame = CGRect(x: 100, y: 60, width: 180, height: 250)
        popoverAnimator.presentedCallBack = {[weak self] (isPresented) -> () in
            self?.titleBtn.selected = isPresented
        }
        popoverVc.transitioningDelegate = popoverAnimator
        
        // 弹出控制器
        presentViewController(popoverVc, animated: true, completion: nil)
    }
}


// MARK:- tableView的数据源和代理方法
extension HomeViewController {
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return statusViewModels.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        // 1.创建cell
        let cell = tableView.dequeueReusableCellWithIdentifier("HomeCell")! as! HomeViewCell
        
        // 2.给cell设置数据
        cell.statusViewModel = statusViewModels[indexPath.row]
        
        return cell
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        // 1.从缓存中获取高度
        if let height = cellHeightCache["\(indexPath.row)"] {
            return height
        }
        
        // 2.获取模型对象
        let statusViewModel = statusViewModels[indexPath.row]
        
        // 3.取出cell
        let cell = tableView.dequeueReusableCellWithIdentifier("HomeCell") as! HomeViewCell
        
        // 4.计算cell的高度
        let height = cell.calculateCellHeight(statusViewModel)
        
        // 5.将height缓存
        cellHeightCache["\(indexPath.row)"] = height
        
        return height
    }
}


// MARK:- 加载首页微博
extension HomeViewController {
    private func loadStatus() {
        NetworkTools.shareIntance.loadStatus { (results, error) -> () in
            // 1.错误校验
            if error != nil {
                print(error)
                return
            }
            
            // 2.将微博字典转成模型对象,并且放入到数组中
            for statusDict in results! {
                self.statusViewModels.append(StatusViewModel(status: Status(dict: statusDict)))
            }
            
            // 3.缓存图片
            self.cacheImages()
        }
    }
    
    private func cacheImages() {
        // 0.创建group
        let group = dispatch_group_create()
        
        // 1.遍历所有的微博数据
        for status in statusViewModels {
            // 2.遍历每一个微博中的图片数据
            for picURL in status.picURLs {
                // 3.缓存图片
                dispatch_group_enter(group)
                SDWebImageManager.sharedManager().downloadImageWithURL(picURL, options: [], progress: nil, completed: { (image, error, _, _, _) -> Void in
                    dispatch_group_leave(group)
                    print("下载了一张图片")
                })
            }
        }
        
        // 4.刷新表格
        dispatch_group_notify(group, dispatch_get_main_queue()) { () -> Void in
            self.tableView.reloadData()
        }
    }
}