//
//  ComposeViewController.swift
//  DSWB
//
//  Created by apple on 16/3/16.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class ComposeViewController: UIViewController {
    // MARK:- 懒加载控件
    private lazy var titleView : ComposeTitleView = ComposeTitleView()
    
    // MARK:- 系统回调函数
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1.布局导航栏
        setupNavigationBar()
    }
}


// MARK:- 设置UI界面内容
extension ComposeViewController {
    /// 设置导航栏的内容
    private func setupNavigationBar() {
        // 1.设置左侧的按钮
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "关闭", style: .Plain, target: self, action: "closeItemClick")
        
        // 2.设置右侧的按钮
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "发送", style: .Plain, target: self, action: "sendItemClick")
        
        // 3.标题的设置
        titleView.frame = CGRect(x: 0, y: 0, width: 100, height: 40)
        navigationItem.titleView = titleView
        titleView.screenNameLabel.text = UserAccountViewModel.shareIntance.userAccount?.screen_name
    }
}


// MARK:- 事件点击的函数
extension ComposeViewController {
    /// 监听关闭按钮
    @objc private func closeItemClick() {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    /// 监听发布按钮
    @objc private func sendItemClick() {
        print("sendItemClick")
    }
}