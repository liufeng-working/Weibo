//
//  Common.swift
//  DS11WB
//
//  Created by xiaomage on 16/4/6.
//  Copyright © 2016年 小码哥. All rights reserved.
//

import Foundation

// MARK:- 授权的常量
let app_key = "3467343333"
let app_secret = "99cffaeff85c7e8e18a95913de1479d7"
let redirect_uri = "http://www.520it.com"