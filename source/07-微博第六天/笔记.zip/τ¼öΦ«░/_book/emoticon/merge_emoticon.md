# 整合表情键盘

* 将测试项目中的 `Emoticon` 拖拽至项目中
* 在 `ComposeViewController` 中添加以下代码

```swift
/// 表情键盘控制器
private lazy var emoticonViewController: EmoticonViewController = EmoticonViewController { [weak self] (emoticon) -> () in
    
    self?.textView.insertEmoticon(emoticon)
}
```

* 定义切换键盘函数

```
/// 选择表情键盘
@objc private func selectEmoticon() {
    
}
```

* 修改 `prepareToolBar` 函数，设置按钮监听方法

```swift
let itemSettings = [["imageName": "compose_toolbar_picture", "actionName": "selectPhoto"],
    ["imageName": "compose_mentionbutton_background"],
    ["imageName": "compose_trendbutton_background"],
    ["imageName": "compose_emoticonbutton_background", "actionName": "selectEmoticon"],
    ["imageName": "compose_addbutton_background"]]
```

* 修改切换键盘函数

```swift
/// 选择表情键盘
@objc private func selectEmoticon() {
    textView.resignFirstResponder()
    
    textView.inputView = textView.inputView == nil ? emoticonViewController.view : nil
    
    textView.becomeFirstResponder()
}
```

> 运行测试会发现键盘会上下跳动

## 动画选项

* 修改键盘监听的动画方法

```swift
// 动画曲线选项
let curve = (n.userInfo![UIKeyboardAnimationCurveUserInfoKey] as! NSNumber).integerValue

...

// 动画
UIView.animateWithDuration(duration) { () -> Void in
    UIView.setAnimationCurve(UIViewAnimationCurve(rawValue: curve)!)
    self.view.layoutIfNeeded()
}
```

> 苹果官方没有提供关于 `UIViewAnimationCurve` 数值等于 `7` 的文档说明，不过通过实际测试发现，可以设置动画的优先级

* UIViewAnimationCurve == 7 时
    * 如果图层之前动画没有结束，会被终止并执行后续的动画
    * 同时将动画时长修改为 `0.5 s`，并且设定的动画时长不再有效

* 测试动画时长

```swift
let anim = toolbar.layer.animationForKey("position")
print("动画时长 \(anim?.duration)")
```

## `textViewDidChange` 代理方法

* 问题：输入表情符号不会触发 `textView` 的 `textViewDidChange` 代理方法

* 在 `UITextView+emoticons` 的 `insertEmoticon` 函数末尾添加以下代码，主动调用代理方法

```swift
// 4> 主动调用代理方法
delegate?.textViewDidChange!(self)
```

### 修改发布微博文本内容

```swift
let text = textView.emoticonText
```

## 修改为单例

* 由于表情符号使用的非常频繁，为了避免重复加载 plist，可以将表情的视图模型修改为单例

* 在 `EmoticonViewModel` 增加单例常量

```swift
/// 单例
static let sharedViewModel = EmoticonViewModel()
```

* 将 `init()` 函数中增加 `private`

```swift
private init() {
    loadEmoticons()
}
```

* 将 `loadEmoticons` 函数修改为 `private` 

```swift
private func loadEmoticons() {
```

* 修改 `EmoticonViewController` 中的视图模型属性

```swift
/// 视图模型
private lazy var viewModel = EmoticonViewModel.sharedViewModel
```