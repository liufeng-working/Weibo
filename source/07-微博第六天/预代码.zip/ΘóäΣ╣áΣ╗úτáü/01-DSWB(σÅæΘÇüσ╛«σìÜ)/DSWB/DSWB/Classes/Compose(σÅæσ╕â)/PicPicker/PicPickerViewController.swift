//
//  PicPickerViewController.swift
//  DSWB
//
//  Created by apple on 16/3/16.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

private let reuseIdentifier = "Cell"
private let edgeMargin : CGFloat = 10
private let imageMargin : CGFloat = 10

class PicPickerViewController: UICollectionViewController {
    // MARK:- 定义属性
    lazy var images : [UIImage] = [UIImage]()
    
    // MARK:- 系统回调函数
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 设置view的背景颜色
        
        // Register cell classes
        self.collectionView!.registerNib(UINib(nibName: "PicPickerViewCell", bundle: nil), forCellWithReuseIdentifier: reuseIdentifier)
    }
}

extension PicPickerViewController {
    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return images.count + 1
    }
    
    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        // 1.创建cell
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(reuseIdentifier, forIndexPath: indexPath) as! PicPickerViewCell
        
        // 2.给cell设置数据
        cell.delegate = self
        cell.image = indexPath.item < images.count ? images[indexPath.item] : nil
        
        return cell
    }
}

extension PicPickerViewController : PicPickerViewCellDelegate {
    func picPickerViewCellWithaddPhotoBtnClick(cell: PicPickerViewCell) {
        // 1.判断照片源是否可用
        if !UIImagePickerController.isSourceTypeAvailable(.PhotoLibrary) {
            return
        }
        
        // 2.创建照片选择控制器
        let ipc = UIImagePickerController()
        
        // 3.设置照片源
        ipc.sourceType = .PhotoLibrary
        
        // 4.设置代理
        ipc.delegate = self
        
        // 5.弹出控制器
        presentViewController(ipc, animated: true, completion: nil)
    }
    
    func PicPickerViewCellWithRemovePhotBtnClick(cell: PicPickerViewCell) {
        // 1.获取cell所在的indexPath
        let indexPath = (collectionView?.indexPathForCell(cell))!
        
        // 2.将图片从数组中删除
        images.removeAtIndex(indexPath.item)
        
        // 3.刷新表格
        collectionView?.reloadData()
    }
}

extension PicPickerViewController : UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        // 1.获取选中的照片
        let image = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        // 2.将图片添加到数组中
        images.append(image)
        
        // 3.刷新表格
        collectionView?.reloadData()
        
        // 4.退出控制器
        picker.dismissViewControllerAnimated(true, completion: nil)
    }
}


class PicPickerCollectionViewLayout : UICollectionViewFlowLayout {
    override func prepareLayout() {
        super.prepareLayout()
        
        // 1.计算图片的宽度高度
        let imageWH = (UIScreen.mainScreen().bounds.width - 2 * edgeMargin - 2 * imageMargin) / 3
        
        // 2.设置item的size
        itemSize = CGSize(width: imageWH, height: imageWH)
        minimumInteritemSpacing = imageMargin
        minimumLineSpacing = imageMargin
        
        // 3.设置collectionView的内边距
        collectionView?.contentInset = UIEdgeInsets(top: edgeMargin, left: edgeMargin, bottom: edgeMargin, right: edgeMargin)
        collectionView?.backgroundColor = UIColor(red: 246/255.0, green: 246/255.0, blue: 246/255.0, alpha: 1.0)
    }
}