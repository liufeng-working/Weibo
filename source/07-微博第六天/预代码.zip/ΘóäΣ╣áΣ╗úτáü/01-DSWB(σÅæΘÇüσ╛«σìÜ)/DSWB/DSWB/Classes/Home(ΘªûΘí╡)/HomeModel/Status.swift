//
//  Status.swift
//  DSWB
//
//  Created by apple on 16/3/15.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class Status: NSObject {
    // MARK:- 属性
    /// 创建时间
    var created_at : String?
    /// 微博ID
    var id : Int = 0
    /// 微博正文
    var text : String?
    /// 微博的来源
    var source : String?
    /// 用户属性
    var user : User?
    /// 添加图片属性
    var pic_urls : [[String : String]]?
    /// 添加转发微博
    var retweeted_status : Status?
    
    // MARK:- 构造函数
    init(dict : [String : AnyObject]) {
        super.init()
        
        setValuesForKeysWithDictionary(dict)
        
        if let userDict = dict["user"] as? [String : AnyObject] {
            user = User(dict: userDict)
        }
        
        if let retweetedStatusDict = dict["retweeted_status"] as? [String : AnyObject] {
            retweeted_status = Status(dict: retweetedStatusDict)
        }
    }
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {}
}
