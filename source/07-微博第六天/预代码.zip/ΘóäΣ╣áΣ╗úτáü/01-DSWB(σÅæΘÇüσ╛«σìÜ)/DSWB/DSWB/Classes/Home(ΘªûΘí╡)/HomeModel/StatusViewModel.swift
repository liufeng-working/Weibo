//
//  StatusViewModel.swift
//  DSWB
//
//  Created by apple on 16/3/15.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class StatusViewModel {
    // MARK:- 属性
    var status : Status?
    
    /// 微博创建时间
    var createAtText : String? {
        return NSDate.createTimeWithString(status?.created_at ?? "")
    }
    
    /// 微博来源
    var sourceText : String?
    
    /// 会员等级
    var mbRankImage : UIImage?
    
    /// 认证类型
    var verifiedImage : UIImage?
    
    /// 头像地址
    var profileURL : NSURL?
    
    
    /// 图片属性
    var picURLs : [NSURL] = [NSURL]()
    
    // MARK:- 构造函数
    init (status : Status) {
        self.status = status
        
        // 1.来源处理
        if let source = status.source where status.source != "" {
            // 1.获取其实位置
            let startIndex = (source as NSString).rangeOfString(">").location + 1
            
            // 2.获取截取的长度
            let length = (source as NSString).rangeOfString("</").location - startIndex
            
            // 3.获取来源的字符串
            sourceText = "来自 " + (source as NSString).substringWithRange(NSRange(location: startIndex, length: length))
        }
        
        // 2.认证图标的处理
        switch status.user?.verified_type ?? -1 {
            case 0:
                verifiedImage = UIImage(named: "avatar_vip")
            case 2, 3, 5:
                verifiedImage = UIImage(named: "avatar_enterprise_vip")
            case 220:
                verifiedImage = UIImage(named: "avatar_grassroot")
            default:
                verifiedImage = nil
        }
        
        // 3.会员图标的处理
        let mbrank = status.user?.mbrank ?? 0
        if mbrank >= 1 && mbrank <= 6 {
            mbRankImage = UIImage(named: "common_icon_membership_level\(mbrank)")
        }
        
        // 4.用户头像
        if let profileURLString = status.user?.profile_image_url {
            profileURL = NSURL(string: profileURLString)
        }
        
        // 5.图片数据处理
        // 5.图片数据处理
        let dictURLs = status.pic_urls?.count != 0 ? status.pic_urls : status.retweeted_status?.pic_urls
        if let dictURLs = dictURLs {
            for urlDict in dictURLs {
                guard let urlString = urlDict["thumbnail_pic"] else {
                    continue
                }
                
                picURLs.append(NSURL(string: urlString)!)
            }
        }
    }
}
