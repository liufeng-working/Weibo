//
//  PicCollectionView.swift
//  DSWB
//
//  Created by apple on 16/3/16.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit
import SDWebImage

private let padding : CGFloat = 10


class PicCollectionView: UICollectionView {
    // MARK:- 约束属性
    @IBOutlet weak var picViewLeftCons: NSLayoutConstraint!
    @IBOutlet weak var picViewHeightCons: NSLayoutConstraint!
    
    // MARK:- 属性
    var picURLs : [NSURL] = [NSURL]() {
        didSet {
            // 1.计算collectionView的右侧和高度约束
            let (height, right) = calculatePicViewCons(picURLs.count)
            picViewLeftCons.constant = right
            picViewHeightCons.constant = height
            
            // 2.设置布局
            setupLayut()
            
            // 3.刷新表格
            reloadData()
        }
    }
    
    // MARK:- 系统回调函数
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // 1.设置collectionView的属性
        self.dataSource = self
    }
}

extension PicCollectionView {
    /// 设置layout布局
    private func setupLayut() {
        // 1.计算itemSize
        var itemSize = CGSizeZero
        if picURLs.count == 1 {
            let image = SDWebImageManager.sharedManager().imageCache.imageFromDiskCacheForKey(picURLs.first!.absoluteString)
            itemSize = CGSize(width: image.size.width * 2, height: image.size.height * 2)
        } else {
            let imageWH = (UIScreen.mainScreen().bounds.width - 2 * leftMargin - 2 * padding) / 3
            itemSize = CGSizeMake(imageWH, imageWH)
        }
        
        // 2.取出layout
        let layout = self.collectionViewLayout as! UICollectionViewFlowLayout
        layout.itemSize = itemSize
        layout.minimumInteritemSpacing = padding
        layout.minimumLineSpacing = padding
    }
    
    /// 计算图片View的左侧和高度约束
    private func calculatePicViewCons(count : Int) -> (CGFloat, CGFloat) {
        // 计算宽度和高度
        let imageWH = (UIScreen.mainScreen().bounds.width - 2 * leftMargin - 2 * padding) / 3
        
        // 没有图片
        if count == 0 {
            return (0, leftMargin)
        }
        
        
        // 一张图片
        if count == 1 {
            let image = SDWebImageManager.sharedManager().imageCache.imageFromDiskCacheForKey(picURLs.first!.absoluteString)
            let rightMargin = UIScreen.mainScreen().bounds.width - leftMargin - image.size.width * 2 - padding
            
            return (image.size.height * 2, rightMargin)
        }
        
        // 四张图片
        if count == 4 {
            let height = imageWH * 2 + padding
            let right = UIScreen.mainScreen().bounds.width - leftMargin - padding - 2 * imageWH - 1
            
            return (height, right)
        }
        
        // 其他图片
        let row = CGFloat((count - 1) / 3 + 1)
        let height = row * imageWH + (row - 1) * padding
        let right = leftMargin
        return (height, right)
    }
}

extension PicCollectionView : UICollectionViewDataSource {
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return picURLs.count
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        // 1.取出cell
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("picCellID", forIndexPath: indexPath) as! PicCollectionViewCell
        
        // 2.给cell设置数据
        cell.picURL = picURLs[indexPath.item]
        
        return cell
    }
}

class PicCollectionViewCell : UICollectionViewCell {
    // MARK:- 定义属性
    var picURL : NSURL? {
        didSet {
            picImageView.sd_setImageWithURL(picURL, placeholderImage: UIImage(named: "empty_picture"))
        }
    }
    
    // MARK:- 控件属性
    @IBOutlet weak var picImageView: UIImageView!
}
