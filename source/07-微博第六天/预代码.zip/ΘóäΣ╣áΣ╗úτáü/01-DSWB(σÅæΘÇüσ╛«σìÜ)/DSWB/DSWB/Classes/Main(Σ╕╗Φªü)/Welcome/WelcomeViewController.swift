//
//  WelcomeViewController.swift
//  DSWB
//
//  Created by apple on 16/3/14.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit
import SDWebImage

class WelcomeViewController: UIViewController {
    // MARK:- 控件属性
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var iconImageViewTopCons: NSLayoutConstraint!
    
    
    // MARK:- 系统回调函数
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1.设置头像的图片
        iconImageView.sd_setImageWithURL(UserAccountViewModel.shareIntance.userAccount?.avatar_url, placeholderImage: UIImage(named: "avatar_default_big"))
        
        // 2.执行动画
        iconImageViewTopCons.constant = 100
        UIView.animateWithDuration(1.0, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 5.0, options: [], animations: { () -> Void in
            self.view.layoutIfNeeded()
            self.welcomeLabel.alpha = 1.0
            }) { (_) -> Void in
                UIApplication.sharedApplication().keyWindow?.rootViewController = UIStoryboard(name: "Main", bundle: nil).instantiateInitialViewController()!
        }
    }
}
