//
//  NSDate-Extension.swift
//  04-时间的处理
//
//  Created by apple on 16/3/15.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import Foundation


extension NSDate {
    class func createTimeWithString(timeString : String) -> String {
        // 1.创建时间格式化对象
        let fmt = NSDateFormatter()
        fmt.locale = NSLocale(localeIdentifier: "en")
        fmt.dateFormat = "EEE MM dd HH:mm:ss Z yyyy"
        
        // 2.获取时间
        guard let createDate = fmt.dateFromString(timeString) else {
            return ""
        }
        
        // 3.获取当前时间
        let nowDate = NSDate()
        
        // 4.获取创建时间和当前时间差
        let interval = Int(nowDate.timeIntervalSinceDate(createDate))
        
        // 5.判断时间显示的格式
        // 5.1.1分钟之内
        if interval < 60 {
            return "刚刚"
        }
        
        // 5.2.一个小时内
        if interval < 60 * 60 {
            return "\(interval / 60)分钟前"
        }
        
        // 5.3.一天之内
        if interval < 60 * 60 * 24 {
            return "\(interval / 60 / 60)小时前"
        }
        
        // 6.其他时间的显示
        // 6.1.创建日期对象
        let calendar = NSCalendar.currentCalendar()
        
        // 6.2.昨天的显示
        if calendar.isDateInYesterday(createDate) {
            fmt.dateFormat = "HH:mm"
            let timeString = fmt.stringFromDate(createDate)
            return "昨天 \(timeString)"
        }
        
        // 6.3.一年之内
        let cpns = calendar.components(NSCalendarUnit.Year, fromDate: createDate, toDate: nowDate, options: [])
        if cpns.year < 1 {
            fmt.dateFormat = "MM-dd HH:mm"
            let timeString = fmt.stringFromDate(createDate)
            return timeString
        }
        
        // 6.4.一年以上
        fmt.dateFormat = "yyyy-MM-dd HH:mm"
        let timeString = fmt.stringFromDate(createDate)
        
        return timeString
    }
}