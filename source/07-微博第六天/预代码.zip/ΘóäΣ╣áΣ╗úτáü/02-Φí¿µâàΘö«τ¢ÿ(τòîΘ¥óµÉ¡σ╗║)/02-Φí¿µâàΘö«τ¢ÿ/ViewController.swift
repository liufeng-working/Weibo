//
//  ViewController.swift
//  02-表情键盘
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var customTextView: UITextView!
    
    private lazy var emoticonVc : EmoticonViewController = EmoticonViewController()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        customTextView.inputView = emoticonVc.view
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        customTextView.becomeFirstResponder()
    }
}

