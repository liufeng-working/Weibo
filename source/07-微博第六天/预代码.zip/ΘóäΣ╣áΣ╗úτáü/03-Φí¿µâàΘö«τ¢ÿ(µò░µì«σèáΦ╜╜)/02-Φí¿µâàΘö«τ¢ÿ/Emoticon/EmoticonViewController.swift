//
//  EmoticonViewController.swift
//  02-表情键盘
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

private let emoticonCellID = "emoticonCellID"

class EmoticonViewController: UIViewController {
    // 懒加载属性
    private lazy var collectionView : UICollectionView = UICollectionView(frame: CGRectZero, collectionViewLayout: EmoticonCollectionViewLayout())
    private lazy var toolBar : UIToolbar = UIToolbar()
    
    // MARK:- 系统回到函数
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 设置UI相关
        setupUI()
        
        let manager = EmoticonManager()
        
        for package in manager.emoticonPackages {
            for emoticon in package.emoticons {
                print(emoticon)
            }
        }
    }
    
}


// MARK:- 设置UI界面
extension EmoticonViewController {
    private func setupUI() {
        // 1.添加子控件
        view.addSubview(collectionView)
        view.addSubview(toolBar)
        collectionView.backgroundColor = UIColor(white: 0.97, alpha: 1.0)
        toolBar.backgroundColor = UIColor.lightGrayColor()
        
        // 2.设置控件的位置和尺寸
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        toolBar.translatesAutoresizingMaskIntoConstraints = false
        let views = ["collectionView" : collectionView, "toolBar" : toolBar]
        var cons = NSLayoutConstraint.constraintsWithVisualFormat("H:|-0-[collectionView]-0-|", options: [], metrics: nil, views: views)
        cons += NSLayoutConstraint.constraintsWithVisualFormat("V:|-0-[collectionView]-0-[toolBar(44)]-0-|", options: [.AlignAllLeft, .AlignAllRight], metrics: nil, views: views)
        view.addConstraints(cons)
        
        // 3.准备collectionView
        prepareCollectionView()
        
        // 4.准备toolbar
        prepareToolBar()
    }
    
    /// 准备collectionView
    private func prepareCollectionView() {
        // 设置collectionView的属性
        collectionView.dataSource = self
        collectionView.registerClass(EmoticonViewCell.self, forCellWithReuseIdentifier: emoticonCellID)
    }
    
    /// 准备toolBar
    private func prepareToolBar() {
        // 1.定义标题的数组
        let titles = ["最近", "默认", "emoji", "浪小花"]
        
        // 2.遍历数组,并且添加UIBarButtonItem
        var items = [UIBarButtonItem]()
        for i in 0..<titles.count {
            // 2.1.取出标题
            let title = titles[i]
            
            // 2.2.创建UIBarButtonItem
            let item = UIBarButtonItem(title: title, style: .Plain, target: self, action: "itemClick:")
            item.tintColor = UIColor.orangeColor()
            
            // 2.3.添加item
            items.append(item)
            
            // 2.4.添加弹簧
            items.append(UIBarButtonItem(barButtonSystemItem: .FlexibleSpace, target: nil, action: nil))
        }
        
        // 3.赋值给toolBar的items数组
        items.removeLast()
        toolBar.items = items
    }
}



// MARK:- 事件监听函数
extension EmoticonViewController {
    @objc private func itemClick(item : UIBarButtonItem) {
        print(item.tag)
    }
}


// MARK:- collectionView的数据源方法
extension EmoticonViewController : UICollectionViewDataSource {
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 100
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        // 1.创建cell
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(emoticonCellID, forIndexPath: indexPath) as! EmoticonViewCell
        
        // 2.给cell设置数据
        cell.backgroundColor = indexPath.item % 2 == 0 ? UIColor.redColor() : UIColor.blueColor()
        
        return cell
    }
}
