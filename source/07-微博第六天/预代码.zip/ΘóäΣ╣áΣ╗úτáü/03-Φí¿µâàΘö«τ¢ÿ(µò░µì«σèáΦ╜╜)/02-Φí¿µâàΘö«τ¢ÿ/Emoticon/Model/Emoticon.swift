//
//  Emoticon.swift
//  02-表情键盘
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class Emoticon: NSObject {
    // MARK:- 属性
    /// Emoji对应的code
    var code : String?
    
    /// 表情对应的文字
    var chs : String?
    
    /// 表情对应的图片
    var png : String?
    
    // MARK:- 构造函数
    init(dict : [String : AnyObject]) {
        super.init()
        
        setValuesForKeysWithDictionary(dict)
    }
    
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {}
    
    override var description : String {
        return dictionaryWithValuesForKeys(["code", "chs", "png"]).description
    }
}
