//
//  EmoticonManager.swift
//  02-表情键盘
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class EmoticonManager {
    // MARK:- 属性
    lazy var emoticonPackages : [EmoticonPackage] = [EmoticonPackage]()
    
    // MARK:- 构造函数
    init () {
        // 1.添加最近表情组
        emoticonPackages.append(EmoticonPackage())
        
        // 2.添加默认组
        emoticonPackages.append(EmoticonPackage(id: "com.sina.default"))
        
        // 3.添加emoji组
        emoticonPackages.append(EmoticonPackage(id: "com.apple.emoji"))
        
        // 4.添加浪小花组
        emoticonPackages.append(EmoticonPackage(id: "com.sina.lxh"))
    }
}
