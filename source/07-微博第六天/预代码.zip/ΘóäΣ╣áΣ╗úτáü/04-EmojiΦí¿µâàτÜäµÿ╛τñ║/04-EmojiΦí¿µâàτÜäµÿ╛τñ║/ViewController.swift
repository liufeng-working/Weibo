//
//  ViewController.swift
//  04-Emoji表情的显示
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let code = "0x1f603"
        
        // 1.创建扫描
        let scanner = NSScanner(string: code)
        
        // 2.定义变量
        var value : UInt32 = 0
        scanner.scanHexInt(&value)
        
        // 3.将value转成字符
        let c = Character(UnicodeScalar(value))
        
        // 4.将字符转成字符串
        let emojiStr = String(c)
        
        print(emojiStr)
    }
}

