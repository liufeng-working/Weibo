//
//  Emoticon.swift
//  02-表情键盘
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class Emoticon: NSObject {
    // MARK:- 属性
    /// Emoji对应的code
    var code : String? {
        didSet {
            // 0.nil值校验
            guard let code = code else {
                return
            }
            
            // 1.创建扫描
            let scanner = NSScanner(string: code)
            
            // 2.定义变量
            var value : UInt32 = 0
            scanner.scanHexInt(&value)
            
            // 3.将value转成字符
            let c = Character(UnicodeScalar(value))
            
            // 4.将字符转成字符串
            emojiCode = String(c)
        }
    }
    
    /// 表情对应的文字
    var chs : String?
    
    /// 表情对应的图片
    var png : String? {
        didSet {
            // 1.nil值校验
            guard let png = png else {
                return
            }
            
            // 2.拼接路径
            pngPath = NSBundle.mainBundle().bundlePath + "/Emoticons.bundle/" + png
        }
    }
    
    
    /// 对code处理后的emoji表情
    var emojiCode : String?
    
    /// 对png处理后的pngPath
    var pngPath : String?
    
    // MARK:- 构造函数
    init(dict : [String : AnyObject]) {
        super.init()
        
        setValuesForKeysWithDictionary(dict)
    }
    
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {}
    
    override var description : String {
        return dictionaryWithValuesForKeys(["emojiCode", "chs", "pngPath"]).description
    }
}
