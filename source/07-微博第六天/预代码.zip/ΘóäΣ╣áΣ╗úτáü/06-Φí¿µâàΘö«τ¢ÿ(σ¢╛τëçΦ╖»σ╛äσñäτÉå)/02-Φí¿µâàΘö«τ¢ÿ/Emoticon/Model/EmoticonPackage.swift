//
//  EmoticonPackage.swift
//  02-表情键盘
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class EmoticonPackage: NSObject {
    // MARK:- 懒加载属性
    lazy var emoticons : [Emoticon] = [Emoticon]()
    
    // MARK:- 构造函数
    override init() {
        
    }
    
    init(id : String) {
        super.init()
        
        // 1.获取info.plist的文件路径
        let infoPlistPath = NSBundle.mainBundle().pathForResource("\(id)/info.plist", ofType: nil, inDirectory: "Emoticons.bundle")!
        
        // 2.加载info.plist中的数据
        guard let dictArray = NSArray(contentsOfFile: infoPlistPath) as? [[String : AnyObject]] else {
            return
        }
        
        // 3.遍历数组,将数组中的字典转成模型对象
        for var dict in dictArray {
            
            if let png = dict["png"] as? String {
                dict["png"] = id + "/" + png
            }
            
            self.emoticons.append(Emoticon(dict: dict))
        }
    }
}
