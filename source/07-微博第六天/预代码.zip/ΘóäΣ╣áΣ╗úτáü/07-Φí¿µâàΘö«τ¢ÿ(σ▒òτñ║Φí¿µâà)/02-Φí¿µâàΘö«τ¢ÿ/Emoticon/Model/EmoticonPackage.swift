//
//  EmoticonPackage.swift
//  02-表情键盘
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class EmoticonPackage: NSObject {
    // MARK:- 懒加载属性
    lazy var emoticons : [Emoticon] = [Emoticon]()
    
    // MARK:- 构造函数
    override init() {
        super.init()
        
        addEmptyEmoticon()
    }
    
    init(id : String) {
        super.init()
        
        // 1.获取info.plist的文件路径
        let infoPlistPath = NSBundle.mainBundle().pathForResource("\(id)/info.plist", ofType: nil, inDirectory: "Emoticons.bundle")!
        
        // 2.加载info.plist中的数据
        guard let dictArray = NSArray(contentsOfFile: infoPlistPath) as? [[String : AnyObject]] else {
            return
        }
        
        // 3.遍历数组,将数组中的字典转成模型对象
        var index = 0
        for var dict in dictArray {
            index++
            if let png = dict["png"] as? String {
                dict["png"] = id + "/" + png
            }
            
            self.emoticons.append(Emoticon(dict: dict))
            
            if index % 20 == 0 {
                self.emoticons.append(Emoticon(isRemove: true))
            }
        }
        
        // 4.添加空白表情
        addEmptyEmoticon()
    }
    
    private func addEmptyEmoticon() {
        // 1.取出少多少个表情
        let missCount = emoticons.count % 21
        
        // 2.判断是否需要添加
        if missCount == 0 && emoticons.count != 0 {
            return
        }
        
        // 3.添加空白表情
        for _ in missCount..<20 {
            self.emoticons.append(Emoticon(isEmpty: true))
        }
        
        self.emoticons.append(Emoticon(isRemove: true))
    }
}
