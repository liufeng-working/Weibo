//
//  EmoticonManager.swift
//  02-表情键盘
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class EmoticonManager {
    
    // MARK:- 属性
    lazy var emoticonPackages : [EmoticonPackage] = [EmoticonPackage]()
    
    // MARK:- 构造函数
    init () {
        // 1.添加最近表情组
        emoticonPackages.append(EmoticonPackage())
        
        // 2.添加默认组
        emoticonPackages.append(EmoticonPackage(id: "com.sina.default"))
        
        // 3.添加emoji组
        emoticonPackages.append(EmoticonPackage(id: "com.apple.emoji"))
        
        // 4.添加浪小花组
        emoticonPackages.append(EmoticonPackage(id: "com.sina.lxh"))
    }
    
    // MARK:- 插入最近表情
    func insertRecentlyEmoticon(emoticon : Emoticon) {
        // 1.判断是否已经包含了该表情
        let emoticons = emoticonPackages.first?.emoticons
        if emoticons!.contains(emoticon) {
            let index = (emoticons?.indexOf(emoticon))!
            emoticonPackages.first?.emoticons.removeAtIndex(index)
        } else {
            emoticonPackages.first?.emoticons.removeAtIndex(20)
        }
        
        // 2.插入表情
        emoticonPackages.first?.emoticons.insert(emoticon, atIndex: 0)
    }
}
