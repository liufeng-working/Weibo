//
//  ComposeViewController.swift
//  DSWB
//
//  Created by apple on 16/3/16.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit
import SnapKit
import SVProgressHUD

class ComposeViewController: UIViewController {
    // MARK:- 懒加载控件
    private lazy var titleView : ComposeTitleView = ComposeTitleView()
    private lazy var picPickerVc : PicPickerViewController = PicPickerViewController(collectionViewLayout: PicPickerCollectionViewLayout())
    private lazy var emoticonVc : EmoticonViewController = EmoticonViewController { (emoticon) -> () in
        
    }
    
    // MARK:- 约束属性
    @IBOutlet weak var toolBarBottomCons: NSLayoutConstraint!
    
    // MARK:- 控件属性
    @IBOutlet weak var customTextView: ComposeTextView!
    @IBOutlet weak var toolBar: UIToolbar!
    
    // MARK:- 系统回调函数
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1.布局导航栏
        setupNavigationBar()
        
        // 2.监听键盘的弹出
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillChangeFrame:", name: UIKeyboardWillChangeFrameNotification, object: nil)
        
        // 3.添加照片选择控制器
        setupPicPickerView()
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        customTextView.becomeFirstResponder()
    }
    
    deinit {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
}


// MARK:- 设置UI界面内容
extension ComposeViewController {
    /// 设置导航栏的内容
    private func setupNavigationBar() {
        // 1.设置左侧的按钮
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "取消", style: .Plain, target: self, action: "closeItemClick")
        
        // 2.设置右侧的按钮
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "发送", style: .Plain, target: self, action: "sendItemClick")
        
        // 3.标题的设置
        titleView.frame = CGRect(x: 0, y: 0, width: 100, height: 40)
        navigationItem.titleView = titleView
        titleView.screenNameLabel.text = UserAccountViewModel.shareIntance.userAccount?.screen_name
    }
    
    
    /// 添加照片选择界面
    private func setupPicPickerView() {
        // 1.添加照片选择的View
        view.insertSubview(picPickerVc.view, belowSubview: toolBar)
        
        // 2.将控制器交给当前控制器管理
        addChildViewController(picPickerVc)
        
        // 3.添加约束
        picPickerVc.view.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(0)
            make.right.equalTo(0)
            make.bottom.equalTo(0)
            make.height.equalTo(0)
        }
    }
}


// MARK:- 事件点击的函数
extension ComposeViewController {
    /// 监听关闭按钮
    @objc private func closeItemClick() {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    /// 监听发布按钮
    @objc private func sendItemClick() {
        // 0.显示正在请求
        SVProgressHUD.show()
        customTextView.resignFirstResponder()
        
        // 1.获取发送微博的内容
        let statusText = customTextView.text
        
        // 2.获取上传的图片
        let image = picPickerVc.images.last
        
        // 3.调用发送微博的接口
        NetworkTools.shareIntance.sendStatus(statusText, image: image) { (isSuccess) -> () in
            if isSuccess {
                SVProgressHUD.showSuccessWithStatus("发送微博成功")
                self.dismissViewControllerAnimated(true, completion: nil)
            } else {
                SVProgressHUD.showErrorWithStatus("发送微博失败")
            }
        }
    }
    
    /// 监听键盘的弹出
    @objc private func keyboardWillChangeFrame(note : NSNotification) {
        // 1.取出键盘弹出的时间
        let duration = note.userInfo![UIKeyboardAnimationDurationUserInfoKey] as! Double
        
        // 2.取出键盘最终的位置
        let endFrame = (note.userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue).CGRectValue()
        
        // 3.计算弹出高度
        let margin = UIScreen.mainScreen().bounds.height - endFrame.origin.y
        
        // 4.执行动画
        toolBarBottomCons.constant = margin
        UIView.animateWithDuration(duration) { () -> Void in
            self.view.layoutIfNeeded()
        }
    }
    
    /// 监听照片Item的点击
    @IBAction func picPickerItemClick() {
        // 0.退出键盘
        customTextView.resignFirstResponder()
        
        // 1.设置约束
        picPickerVc.view.snp_remakeConstraints { (make) -> Void in
            make.left.equalTo(0)
            make.right.equalTo(0)
            make.bottom.equalTo(0)
            make.height.equalTo(self.view).multipliedBy(0.65)
        }
        
        // 2.执行动画
        UIView.animateWithDuration(0.5) { () -> Void in
            self.view.layoutIfNeeded()
        }
    }
    
    @IBAction func switchKeyboard() {
        // 1.退出键盘
        customTextView.resignFirstResponder()
        
        // 2.切换键盘
        if customTextView.inputView == nil {
            customTextView.inputView = emoticonVc.view
        } else {
            customTextView.inputView = nil
        }
        
        // 3.弹出键盘
        customTextView.becomeFirstResponder()
    }
}


// MARK:- textView的代理方法
extension ComposeViewController : UITextViewDelegate {
    func textViewDidChange(textView: UITextView) {
        customTextView.placeHolderLabel.hidden = textView.hasText()
    }
    
    func scrollViewWillBeginDragging(scrollView: UIScrollView) {
        customTextView.resignFirstResponder()
    }
}
