//
//  ViewController.swift
//  02-图文混排
//
//  Created by xiaomage on 16/4/13.
//  Copyright © 2016年 小码哥. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var demoLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let attrStr = NSAttributedString(string: "小码哥", attributes: [NSForegroundColorAttributeName : UIColor.redColor()])
        let attrStr1 = NSAttributedString(string: "IT教育", attributes: [NSForegroundColorAttributeName : UIColor.blueColor()])
        
        // 图文混排
        let attacment = NSTextAttachment()
        attacment.image = UIImage(named: "d_aini")
        let font = demoLabel.font
        attacment.bounds = CGRect(x: 0, y: -4, width: font.lineHeight, height: font.lineHeight)
        let attrImageStr = NSAttributedString(attachment: attacment)
        
        let attrMStr = NSMutableAttributedString()
        attrMStr.appendAttributedString(attrStr)
        attrMStr.appendAttributedString(attrImageStr)
        attrMStr.appendAttributedString(attrStr1)
        
        demoLabel.attributedText = attrMStr
    }
}

