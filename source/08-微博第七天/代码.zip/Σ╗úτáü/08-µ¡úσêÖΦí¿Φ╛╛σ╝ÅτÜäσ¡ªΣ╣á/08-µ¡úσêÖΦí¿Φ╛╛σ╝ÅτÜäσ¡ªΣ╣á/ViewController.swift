//
//  ViewController.swift
//  08-正则表达式的学习
//
//  Created by xiaomage on 16/4/13.
//  Copyright © 2016年 小码哥. All rights reserved.
//

import UIKit

/*
练习1:匹配abc

练习2:包含一个a~z,后面必须是0~9 -->[a-z][0-9]或者[a-z]\d
    * [a-z] : a~z
    * [0-9]/\d : 0~9

练习3:必须第一个是字母,第二个是数字 -->^[a-z][0-9]$
    * ^[a-z] : 表示首字母必须是a~z
    * \d{2,10} : 数字有2到10
    * [a-z]$ : 表示必须以a-z的字母结尾

练习4:必须第一个是字母,字母后面跟上4~9个数字

练习5:不能是数字0-9

    * [^0-9] : 不能是0~9



练习6:QQ匹配:^[1-9]\d{4,11}$
都是数字
5~12位
并且第一位不能是0


练习7:手机号码匹配^1[3578]\d{9}$
1.以13/15/17/18
2.长度是11
*/

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let str = "13324132423"
        
        // 1.创建正则表达式规则
        let pattern = "^1[3578]\\d{9}$"
        
        // 2.创建正则表达式对象(try try? try!)
        guard let regex = try? NSRegularExpression(pattern: pattern, options: []) else {
            return
        }
        
        // 3.匹配字符串中内容
        let results = regex.matchesInString(str, options: [], range: NSRange(location: 0, length: str.characters.count))
        
        // 4.遍历数组,获取结果
        for result in results {
            print((str as NSString).substringWithRange(result.range))
            print(result.range)
        }
    }


}

