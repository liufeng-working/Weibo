//
//  ViewController.swift
//  10-表情的显示
//
//  Created by xiaomage on 16/4/13.
//  Copyright © 2016年 小码哥. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var demoLabel: UILabel!
    
    private lazy var manager : EmoticonManager = EmoticonManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let statusText = "@coderwhy:【动物尖叫合辑】#肥猪流#猫头鹰这么尖叫[偷笑]、@M了个J: 老鼠这么尖叫、兔子这么尖叫[吃惊]、@花满楼: 莫名奇#小笼包#妙的笑到最后[好爱哦]！~ http://t.cn/zYBuKZ8/"
        
        
        demoLabel.attributedText = FindEmoticon.shareIntance.findAttrString(statusText, font: demoLabel.font)
        
        /*
        
        // 1.创建匹配规则
        let pattern = "\\[.*?\\]" // 匹配表情
        
        // 2.创建正则表达式对象
        guard let regex = try? NSRegularExpression(pattern: pattern, options: []) else {
            return
        }
        
        // 3.开始匹配
        let results = regex.matchesInString(statusText, options: [], range: NSRange(location: 0, length: statusText.characters.count))
        
        // 4.获取结果
        let attrMStr = NSMutableAttributedString(string: statusText)
        for var i = results.count - 1; i >= 0; i-- {
            // 4.0.获取结果
            let result = results[i]
            
            // 4.1.获取chs
            let chs = (statusText as NSString).substringWithRange(result.range)
            
            // 4.2.根据chs,获取图片的路径
            guard let pngPath = findPngPath(chs) else {
                return
            }
            
            // 4.3.创建属性字符串
            let attachment = NSTextAttachment()
            attachment.image = UIImage(contentsOfFile: pngPath)
            let font = demoLabel.font
            attachment.bounds = CGRect(x: 0, y: -4, width: font.lineHeight, height: font.lineHeight)
            let attrImageStr = NSAttributedString(attachment: attachment)
            
            // 4.4.将属性字符串替换到来源的文字位置
            attrMStr.replaceCharactersInRange(result.range, withAttributedString: attrImageStr)
        }
        
        // 显示内容
        demoLabel.attributedText = attrMStr
        */
    }
    
    private func findPngPath(chs : String) -> String? {
        for package in manager.packages {
            for emoticon in package.emoticons {
                if emoticon.chs == chs {
                    return emoticon.pngPath
                }
            }
        }
        
        return nil
    }
}

