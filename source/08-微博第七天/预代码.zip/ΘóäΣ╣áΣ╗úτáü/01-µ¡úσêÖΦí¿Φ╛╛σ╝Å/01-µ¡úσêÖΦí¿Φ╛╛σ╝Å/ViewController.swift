//
//  ViewController.swift
//  01-正则表达式
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 微博字符串
        let statusText = "@coderwhy:【动物尖叫合辑】#肥猪流#猫头鹰这么尖叫[偷笑]、@M了个J: 老鼠这么尖叫、兔子这么尖叫[吃惊]、@花满楼: 莫名奇#小笼包#妙的笑到最后[好爱哦]！~ http://t.cn/zYBuKZ8/"
        
        // 1.创建匹配规则
        // let pattern = "@.*?:"
        // let pattern = "#.*?#"
        // let pattern = "\\[.*?\\]"
        let pattern = "http(s)?://([\\w-]+\\.)+[\\w-]+(/[\\w- ./?%&=]*)?"
        
        // 2.创建正则表达式对象
        guard let regex = try? NSRegularExpression(pattern: pattern, options: []) else {
            return
        }
        
        // 3.匹配内容
        let results = regex.matchesInString(statusText, options: [], range: NSRange(location: 0, length: statusText.characters.count))
        
        // 4.获取匹配结果
        for res in results {
            print((statusText as NSString).substringWithRange(res.range))
        }
    }
}

