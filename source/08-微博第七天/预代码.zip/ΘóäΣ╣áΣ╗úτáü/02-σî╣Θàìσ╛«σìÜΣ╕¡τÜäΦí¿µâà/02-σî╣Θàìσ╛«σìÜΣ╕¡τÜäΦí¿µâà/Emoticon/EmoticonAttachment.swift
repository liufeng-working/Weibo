//
//  EmoticonAttachment.swift
//  02-表情键盘
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class EmoticonAttachment: NSTextAttachment {
    var chs : String?
}
