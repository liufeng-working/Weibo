//
//  EmoticonViewCell.swift
//  02-表情键盘
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class EmoticonViewCell: UICollectionViewCell {
    
    // MARK:- 模型对象属性
    var emoticon : Emoticon? {
        didSet {
            // 1.nil值校验
            guard let emoticon = emoticon else {
                return
            }
            
            // 2.设置内容
            emoticonBtn.setImage(UIImage(contentsOfFile: emoticon.pngPath ?? ""), forState: .Normal)
            emoticonBtn.setTitle(emoticon.emojiCode, forState: .Normal)
            
            // 3.显示删除按钮
            if emoticon.isRemove {
                emoticonBtn.setImage(UIImage(named: "compose_emotion_delete"), forState: .Normal)
            }
        }
    }
    
    // MARK:- 控件属性
    private lazy var emoticonBtn : UIButton = UIButton()
    
    // MARK:- 构造函数
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


// MARK:- 设置UI界面
extension EmoticonViewCell {
    /// 设置UI界面
    private func setupUI() {
        // 1.添加子控件
        contentView.addSubview(emoticonBtn)
        
        // 2.设置子控件的位置
        emoticonBtn.frame = CGRectInset(contentView.frame, 3, 3)
        
        // 3.设置btn的属性
        emoticonBtn.titleLabel?.font = UIFont.systemFontOfSize(32)
        emoticonBtn.userInteractionEnabled = false
    }
}