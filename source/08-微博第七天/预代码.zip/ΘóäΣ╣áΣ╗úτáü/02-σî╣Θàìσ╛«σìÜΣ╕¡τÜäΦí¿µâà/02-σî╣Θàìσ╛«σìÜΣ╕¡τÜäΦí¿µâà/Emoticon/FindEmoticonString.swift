//
//  FindEmoticonString.swift
//  02-匹配微博中的表情
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class FindEmoticonString: NSObject {
    // 将类设置为单例
    static let shareInstance : FindEmoticonString = FindEmoticonString()
    
    // 表情数据
    lazy var manager : EmoticonManager = EmoticonManager()
    
    /// 找到字符串中表情对应的属性字符串
    func findEmoticonString(string : String, font : UIFont) -> NSMutableAttributedString? {
        // 1.规则
        let pattern = "\\[.*?\\]"
        
        // 2.创建正则对象
        guard let regex = try? NSRegularExpression(pattern: pattern, options: []) else {
            return nil
        }
        
        // 3.获取匹配结果
        let results = regex.matchesInString(string, options: [], range: NSRange(location: 0, length: string.characters.count))
        
        // 4.遍历所有的字符串
        let attrMStr = NSMutableAttributedString(string: string)
        for var i = results.count - 1; i >= 0; i-- {
            let result = results[i]
            // 4.1.获取chs文字
            let chs = (string as NSString).substringWithRange(result.range)
            
            // 4.2.获取chs对应的pngPath
            guard let pngPath = findPngPathWithChs(chs) else {
                continue
            }
            
            // 4.3.根据图片名称,创建属性字符串
            let attachment = NSTextAttachment()
            attachment.image = UIImage(contentsOfFile: pngPath)
            attachment.bounds = CGRect(x: 0, y: -4, width: font.lineHeight, height: font.lineHeight)
            let attrStr = NSAttributedString(attachment: attachment)
            
            // 4.4.将原微博中的文字替换掉
            attrMStr.replaceCharactersInRange(result.range, withAttributedString: attrStr)
        }
        
        return attrMStr
    }
    
    /// 查找文字对应的pngPath
    private func findPngPathWithChs(chs : String) -> String? {
        for package in manager.emoticonPackages {
            let emoticons = package.emoticons.filter({ (emoticon) -> Bool in
                return emoticon.chs == chs
            })
            
            if emoticons.count != 0 {
                return emoticons.first?.pngPath
            }
        }
        
        return nil
    }
}
