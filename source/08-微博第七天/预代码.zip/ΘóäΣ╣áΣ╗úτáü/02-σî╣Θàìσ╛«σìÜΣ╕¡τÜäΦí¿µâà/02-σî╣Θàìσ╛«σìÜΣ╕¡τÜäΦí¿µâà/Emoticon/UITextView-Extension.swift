//
//  UITextView-Extension.swift
//  02-表情键盘
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

extension UITextView {
    func insertEmoticon(emoticon : Emoticon) {
        // 1.如果是点击了空表情,则直接返回
        if emoticon.isEmpty {
            return
        }
        
        // 2.如果是点击了删除按钮
        if emoticon.isRemove {
            deleteBackward()
            return
        }
        
        // 3.如果是emoji表情
        if emoticon.emojiCode != nil {
            // 3.1.获取光标所在的位置
            let range = selectedTextRange
            
            // 3.2.在光标所在的位置插入表情
            replaceRange(range!, withText: emoticon.emojiCode!)
            
            return
        }
        
        // 4.如果是普通表情
        // 4.0.获取文字
        let tempFont = font!
        
        // 4.1.根据原textView的内容创建可变属性字符串
        let attrMStr = NSMutableAttributedString(attributedString: attributedText)
        
        // 4.2.获取光标所在的位置
        let range = selectedRange
        
        // 4.3.将图片转成属性字符串
        let attachment = EmoticonAttachment()
        attachment.chs = emoticon.chs
        attachment.bounds = CGRect(x: 0, y: -4, width: tempFont.lineHeight, height: tempFont.lineHeight)
        attachment.image = UIImage(contentsOfFile: emoticon.pngPath!)
        let attrStr = NSAttributedString(attachment: attachment)
        
        // 4.4.替换图片
        attrMStr.replaceCharactersInRange(range, withAttributedString: attrStr)
        
        // 4.5.将内容设置成最新的属性字符串
        attributedText = attrMStr
        
        // 4.6.将文字内容设置回原来的大小
        font = tempFont
        
        // 4.7.重写设置光标的位置
        selectedRange = NSRange(location: range.location + 1, length: range.length)
    }
    
    
    func getEmoticonString() -> String {
        // 1.获取属性字符串
        let attrMStr = NSMutableAttributedString(attributedString: attributedText)
        
        // 2.遍历字符串
        let range = NSRange(location: 0, length: attrMStr.length)
        attrMStr.enumerateAttributesInRange(range, options: []) { (dict, range, _) -> Void in
            if let attachment = dict["NSAttachment"] as? EmoticonAttachment {
                attrMStr.replaceCharactersInRange(range, withString: attachment.chs!)
            }
        }
        
        return attrMStr.string
    }
}