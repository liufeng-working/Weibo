//
//  ComposeTitleView.swift
//  DSWB
//
//  Created by apple on 16/3/16.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit
import SnapKit

class ComposeTitleView: UIView {
    // MARK:- 懒加载控件
    private lazy var titleLabel : UILabel = UILabel()
    lazy var screenNameLabel : UILabel = UILabel()
    
    // MARK:- 重写构造函数
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        setupUI()
    }
}

// MARK:- 设置UI界面
extension ComposeTitleView {
    /// 添加子控件
    private func setupUI() {
        // 1.添加子控件
        addSubview(titleLabel)
        addSubview(screenNameLabel)
        
        // 2.设置位置和尺寸
        titleLabel.snp_makeConstraints { (make) -> Void in
            make.centerX.equalTo(self.snp_centerX)
            make.top.equalTo(self.snp_top)
        }
        screenNameLabel.snp_makeConstraints { (make) -> Void in
            make.centerX.equalTo(self.titleLabel.snp_centerX)
            make.top.equalTo(self.titleLabel.snp_bottom).offset(3)
        }
        
        // 3.设置属性
        titleLabel.font = UIFont.systemFontOfSize(15)
        screenNameLabel.font = UIFont.systemFontOfSize(13)
        titleLabel.textColor = UIColor.blackColor()
        screenNameLabel.textColor = UIColor.lightGrayColor()
        titleLabel.text = "发微博"
    }
}
