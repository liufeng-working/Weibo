//
//  HomeViewController.swift
//  DSWB
//
//  Created by apple on 16/3/9.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit
import SDWebImage
import MJRefresh

class HomeViewController: BaseViewController {
    // MARK:- 模型属性
    private lazy var statusViewModels : [StatusViewModel] = [StatusViewModel]()
    
    // MARK:- 懒加载属性
    private lazy var titleBtn : UIButton = TitleButton(type: .Custom)
    private lazy var popoverAnimator = PopoverAnimator()
    private lazy var cellHeightCache : [String : CGFloat] = [String : CGFloat]()
    private lazy var tipLabel : UILabel = UILabel()
    
    // MARK:- 系统回调函数
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1.判断是否登录
        if !isLogin {
            visitorView.addRotationViewAnim()
            return
        }
        
        // 2.设置导航栏的内容
        setupNavigationItems()
        
        // 3.添加下拉刷新
        setupHeaderView()
        // setupFooterView()
        
        // 4.添加提示的Label
        setupTipLabel()
    }
}


// MARK:- 设置UI的内容
extension HomeViewController {
    /// 设置导航栏的内容
    private func setupNavigationItems() {
        // 1.设置左侧导航栏的内容
        navigationItem.leftBarButtonItem = UIBarButtonItem(imageName: "navigationbar_friendattention")
        
        // 2.设置右侧导航栏的内容
        navigationItem.rightBarButtonItem = UIBarButtonItem(imageName: "navigationbar_pop")
        
        // 3.设置导航栏的标题
        titleBtn.setTitle("coderwhy", forState: .Normal)
        titleBtn.addTarget(self, action: "titleBtnClick:", forControlEvents: .TouchUpInside)
        navigationItem.titleView = titleBtn
    }
    
    /// 添加下拉刷新
    private func setupHeaderView() {
        // 1.添加下拉刷新控件
        let headerView = MJRefreshNormalHeader(refreshingTarget: self, refreshingAction: "loadNewData")
        headerView.setTitle("下拉刷新", forState: .Idle)
        headerView.setTitle("释放更新", forState: .Pulling)
        headerView.setTitle("加载中...", forState: .Refreshing)
        tableView.mj_header = headerView
        
        // 2.进入刷新状态
        headerView.beginRefreshing()
    }
    
    /// 添加上拉加载更多
    private func setupFooterView() {
        // 1.创建控件
        let footerView = MJRefreshAutoFooter(refreshingTarget: self, refreshingAction: "loadMoreData")
        
        // 2.设置上拉加载更多
        tableView.mj_footer = footerView
    }
    
    /// 添加提示的Label
    private func setupTipLabel() {
        // 1.添加提示的Label
        navigationController?.navigationBar.insertSubview(tipLabel, atIndex: 0)
        
        // 2.设置位置和尺寸
        tipLabel.frame = CGRect(x: 0, y: 12, width: UIScreen.mainScreen().bounds.width, height: 32)
        
        // 3.设置tipLabel的属性
        tipLabel.backgroundColor = UIColor.orangeColor()
        tipLabel.textColor = UIColor.whiteColor()
        tipLabel.font = UIFont.systemFontOfSize(14)
        tipLabel.textAlignment = .Center
        tipLabel.hidden = true
    }
}


// MARK:- 事件监听函数
extension HomeViewController {
    /// 标题按钮的点击事件
    @objc private func titleBtnClick(titleBtn : TitleButton) {
        // 1.设置按钮的选中状态
        // titleBtn.selected = !titleBtn.selected
        
        // 2.创建PopoverVc
        let popoverVc = PopoverViewController()
        
        // 3.设置弹出样式是自定义(自定义时不会隐藏后面的控制器)
        popoverVc.modalPresentationStyle = .Custom
        
        // 4.设置转场动画的代理
        popoverAnimator.presentedFrame = CGRect(x: 100, y: 60, width: 180, height: 250)
        popoverAnimator.presentedCallBack = {[weak self] (isPresented) -> () in
            self?.titleBtn.selected = isPresented
        }
        popoverVc.transitioningDelegate = popoverAnimator
        
        // 弹出控制器
        presentViewController(popoverVc, animated: true, completion: nil)
    }
}


// MARK:- tableView的数据源和代理方法
extension HomeViewController {
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return statusViewModels.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        // 1.创建cell
        let cell = tableView.dequeueReusableCellWithIdentifier("HomeCell")! as! HomeViewCell
        
        // 2.给cell设置数据
        cell.statusViewModel = statusViewModels[indexPath.row]
        
        // 3.最后一个cell出现时就更新数据
        if indexPath.row == statusViewModels.count - 1 {
            loadMoreData()
        }
        
        return cell
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        // 1.获取模型对象
        let statusViewModel = statusViewModels[indexPath.row]
        
        // 2.从缓存中获取高度
        if let height = cellHeightCache["\(statusViewModel.status!.id)"] {
            return height
        }
        
        // 3.取出cell
        let cell = tableView.dequeueReusableCellWithIdentifier("HomeCell") as! HomeViewCell
        
        // 4.计算cell的高度
        let height = cell.calculateCellHeight(statusViewModel)
        
        // 5.将height缓存
        cellHeightCache["\(statusViewModel.status!.id)"] = height
        
        return height
    }
}


// MARK:- 加载首页微博
extension HomeViewController {
    /// 加载新数据
    @objc private func loadNewData() {
        loadStatus(true)
    }
    
    /// 加载更多数据
    @objc private func loadMoreData() {
        loadStatus(false)
    }
    
    /// 加载数据
    private func loadStatus(isNewData : Bool) {
        var sinceID : Int = 0
        var maxID : Int = 0
        if isNewData {
            sinceID = statusViewModels.first?.status?.id ?? 0
        } else {
            maxID = statusViewModels.last!.status!.id - 1
        }
        
        NetworkTools.shareIntance.loadStatus(sinceID, maxID: maxID) { (results, error) -> () in
            // 1.错误校验
            if error != nil {
                print(error)
                return
            }
            
            // 2.拼接数据
            var models = [StatusViewModel]()
            for dict in results! {
                models.append(StatusViewModel(status: Status(dict: dict)))
            }
            
            // 3.判断是否是最新的数据
            if isNewData {
                self.statusViewModels = models + self.statusViewModels
            } else {
                self.statusViewModels += models
            }
            
            // 4.缓存图片
            self.cacheImages(models.count)
        }
    }
    
    /// 缓存图片
    private func cacheImages(count : Int) {
        // 0.创建group
        let group = dispatch_group_create()
        
        // 1.遍历所有的微博数据
        for status in statusViewModels {
            // 2.遍历每一个微博中的图片数据
            for picURL in status.picURLs {
                // 3.缓存图片
                dispatch_group_enter(group)
                SDWebImageManager.sharedManager().downloadImageWithURL(picURL, options: [], progress: nil, completed: { (image, error, _, _, _) -> Void in
                    dispatch_group_leave(group)
                })
            }
        }
        
        // 4.刷新表格
        dispatch_group_notify(group, dispatch_get_main_queue()) { () -> Void in
            self.tableView.reloadData()
            
            self.tableView.mj_header.endRefreshing()
            // self.tableView.mj_footer.endRefreshing()
            self.showTipLabelAnim(count)
        }
    }
    
    
    /// 显示提示的格式的View
    private func showTipLabelAnim(count : Int) {
        // 1.设置tipLabel的文字内容
        tipLabel.hidden = false
        tipLabel.text = count == 0 ? "没有新数据" : "\(count) 条新数据"
        
        // 2.执行提示Label的动画
        UIView.animateWithDuration(1.0, animations: { () -> Void in
            self.tipLabel.frame.origin.y = 44
            }) { (_) -> Void in
                UIView.animateWithDuration(1.0, delay: 1, options: [], animations: { () -> Void in
                    self.tipLabel.frame.origin.y = 12
                    }, completion: { (_) -> Void in
                        self.tipLabel.hidden = true
                })
        }
    }
}