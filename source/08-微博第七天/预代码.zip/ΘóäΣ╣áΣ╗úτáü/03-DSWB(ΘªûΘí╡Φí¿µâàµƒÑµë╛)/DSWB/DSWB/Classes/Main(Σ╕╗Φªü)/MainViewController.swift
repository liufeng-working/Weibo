//
//  MainViewController.swift
//  DSWB
//
//  Created by apple on 16/3/9.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class MainViewController: UITabBarController {
    // MARK:- 懒加载属性
    private lazy var imageNames : [String] = ["tabbar_home", "tabbar_message_center", "", "tabbar_discover", "tabbar_profile"]
    private lazy var composeBtn : UIButton = UIButton(imageName: "tabbar_compose_icon_add", bgImageName: "tabbar_compose_button")
    
    // MARK:- 系统回调函数
    override func viewDidLoad() {
        super.viewDidLoad()
        setupComposeBtn()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        adjustItems()
    }
}

// MARK:- 设置UI
extension MainViewController {
    /// 调整items
    private func adjustItems() {
        /// 取出所有的item,并且设置图片
        for i in 0..<tabBar.items!.count {
            // 1.取出item
            let item = tabBar.items![i]
            
            // 2.如果是第二个,则不能和用户交互
            if i == 2 {
                item.enabled = false
                continue
            }
            
            // 3.设置item的图片
            item.selectedImage = UIImage(named: imageNames[i] + "_highlighted")
        }
    }
    
    /// 添加发布按钮
    private func setupComposeBtn() {
        // 1.添加发布按钮
        tabBar.addSubview(composeBtn)
        
        // 2.设置位置
        composeBtn.center = CGPoint(x: tabBar.bounds.size.width * 0.5, y: tabBar.bounds.size.height * 0.5)
        
        // 3.监听发布按钮的点击
        composeBtn.addTarget(self, action: "composeBtnClick", forControlEvents: .TouchUpInside)
    }
}

extension MainViewController {
    @objc private func composeBtnClick() {
        // 1.创建发布微博的控制器
        let composeVc = ComposeViewController()
        
        // 2.包装导航控制器
        let composeNav = UINavigationController(rootViewController: composeVc)
        
        // 3.弹出控制器
        presentViewController(composeNav, animated: true, completion: nil)
    }
}
