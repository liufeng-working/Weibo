//
//  XMGLabel.swift
//  05-Lable字符串匹配
//
//  Created by apple on 16/3/19.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit

class XMGLabel: UILabel {
    // MARK:- 懒加载属性
    private lazy var textStorage : NSTextStorage = NSTextStorage()
    private lazy var textManager : NSLayoutManager = NSLayoutManager()
    private lazy var textContainer : NSTextContainer = NSTextContainer()
    
    override var text : String? {
        didSet {
            prepareText()
        }
    }
    
    
    private func prepareText() {
        // 1.将内容转成属性字符串
        let attrMStr = NSMutableAttributedString(string: text ?? "")
        
        // 2.匹配@:
        let pattern = "@.*?:"
        
        // 3.创建正则表达式对象
        let regex = try! NSRegularExpression(pattern: pattern, options: [])
        
        // 4.匹配结果
        let results = regex.matchesInString(attrMStr.string, options: [], range: NSRange(location: 0, length: attrMStr.string.characters.count))
        
        // 5.遍历结果
        for result in results {
            let userName = (attrMStr.string as NSString).substringWithRange(result.range)
            let attrStr = NSAttributedString(string: userName, attributes: [NSForegroundColorAttributeName : UIColor.redColor()])
            attrMStr.replaceCharactersInRange(result.range, withAttributedString: attrStr)
        }
        
        // 6.设置属性文本字符串
        textStorage.setAttributedString(attrMStr)
        
        textStorage.addAttribute(NSFontAttributeName, value: font, range: NSRange(location: 0, length: textStorage.length))
        
        // 7.重画内容
        setNeedsDisplay()
    }
    
    override func drawTextInRect(rect: CGRect) {
        textManager.drawGlyphsForGlyphRange(NSRange(location: 0, length: textStorage.length), atPoint: CGPointZero)
    }
    
    // MARK:- 构造函数
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        prepareSystemText()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        prepareSystemText()
    }
    
    private func prepareSystemText() {
        textStorage.addLayoutManager(textManager)
        textManager.addTextContainer(textContainer)
        
        
        prepareText()
        
        userInteractionEnabled = true
    }
    
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        let point = (touches.first?.locationInView(self))!
        
        let index = textManager.glyphIndexForPoint(point, inTextContainer: textContainer)
        print(index)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        textContainer.size = self.bounds.size
    }
}
