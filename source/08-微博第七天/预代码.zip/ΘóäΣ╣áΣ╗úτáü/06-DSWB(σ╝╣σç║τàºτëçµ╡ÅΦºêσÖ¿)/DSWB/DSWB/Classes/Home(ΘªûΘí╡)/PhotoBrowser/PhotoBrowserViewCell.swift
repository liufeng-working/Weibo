//
//  PhotoBrowserViewCell.swift
//  DSWB
//
//  Created by apple on 16/3/20.
//  Copyright © 2016年 xiaomage. All rights reserved.
//

import UIKit
import SDWebImage

class PhotoBrowserViewCell: UICollectionViewCell {
    // MARK:- 定义模型属性
    var picURL : NSURL? {
        didSet {
            // 1.空值校验
            guard let picURL = picURL else {
                return
            }
            
            // 2.设置界面的内容
            setupUIContent(picURL)
        }
    }
    
    // MARK:- 懒加载属性
    private lazy var scrollView : UIScrollView = UIScrollView()
    private lazy var imageView : UIImageView = UIImageView()
    
    // MARK:- 构造函数
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        setupUI()
    }
}


// MARK:- 设置UI界面
extension PhotoBrowserViewCell {
    private func setupUI() {
        // 1.添加子控件
        contentView.addSubview(scrollView)
        scrollView.addSubview(imageView)
        
        // 2.设置控件的位置和尺寸
        scrollView.frame = contentView.bounds
    }
}


// MARK:- 设置UI内容
extension PhotoBrowserViewCell {
    private func setupUIContent(picURL : NSURL) {
        // 1.取出图片
        let image = SDWebImageManager.sharedManager().imageCache.imageFromMemoryCacheForKey(picURL.absoluteString)
        
        // 2.获取图片高度
        let screenW = UIScreen.mainScreen().bounds.width
        let screenH = UIScreen.mainScreen().bounds.height
        let imageViewH = screenW / image.size.width * image.size.height
        
        // 3.判断是长图还是短图
        if imageViewH > screenH {
            imageView.frame = CGRect(x: 0, y: 0, width: screenW, height: imageViewH)
            scrollView.contentSize = CGSize(width: 0, height: imageViewH)
        } else {
            let imageViewY = (screenH - imageViewH) * 0.5
            imageView.frame = CGRect(x: 0, y: imageViewY, width: screenW, height: imageViewH)
        }
        
        // 4.设置图片
        imageView.image = image
        
        // 5.下载大图
        // 5.1.获取大图的名称
        let bigPicURL = getBigURL(picURL)
        
        // 5.2.下载大图
        imageView.sd_setImageWithURL(bigPicURL, placeholderImage: image, options: [], progress: { (current, total) -> Void in
            
            }, completed: nil)
    }
    
    private func getBigURL(smallURL : NSURL) -> NSURL? {
        // 1.获取小图的字符串
        let smallURLString = smallURL.absoluteString
        
        // 2.获取大图的字符串
        let bigURLString = (smallURLString as NSString).stringByReplacingOccurrencesOfString("thumbnail", withString: "bmiddle")
        
        return NSURL(string: bigURLString)
    }
}